from pathlib import Path
import csv
import json
import os
os.environ.update(OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
import numpy as np

root = Path('/home/ubuntu/project/pr2926-crud-curve-20261022')
identity = json.loads((root/'results/identity.json').read_text())
path = Path(identity['inputs']['GIST']['queries.fvecs']['path'])
with path.open('rb') as stream:
    dim = int.from_bytes(stream.read(4), 'little', signed=True)
data = np.fromfile(path, dtype=np.dtype([('dim', '<i4'), ('vector', '<f4', (dim,))]))
clusters = {}
for q, row in enumerate(data['vector']):
    clusters.setdefault(row.tobytes(), []).append(q)
groups = list(clusters.values())
assert len(data) == 1000 and len(groups) == 998
rng = np.random.default_rng(20261022)
output = []
for mode in ['fp32', 'fp16', 'rabitq8']:
    for number in range(0, 101, 10):
        file = root/'results'/f'GIST-{mode}-0'/f'checkpoint-{number}-queries.csv'
        with file.open() as stream:
            rows = list(csv.DictReader(stream))
        differences = np.array([int(row['fresh_hits'])-int(row['maintained_hits']) for row in rows])
        sums = np.array([differences[group].sum() for group in groups])
        weights = np.array([len(group) for group in groups])
        bootstrap = []
        for _ in range(20):
            selected = rng.integers(0, len(groups), size=(250, len(groups)))
            bootstrap.extend((10*sums[selected].sum(axis=1)/weights[selected].sum(axis=1)).tolist())
        interval = np.quantile(bootstrap, [.025, .975]).tolist()
        output.append(dict(storage=mode, round=number, mutation_calls=number*750,
            fresh_minus_maintained_pp=float(differences.mean()*10),
            query_cluster_bootstrap95_pp=interval,
            fresh_wins=int((differences>0).sum()), maintained_wins=int((differences<0).sum()),
            ties=int((differences==0).sum())))
(root/'paired.json').write_text(json.dumps(dict(rows=output, clusters=len(groups),
    bootstrap_replicates=5000, seed=20261022,
    boundary='Query-cluster resampling conditional on one maintained and one rebuilt graph per checkpoint; not repeated-build confidence, not a project quality gate'), indent=2)+'\n')
print(json.dumps(output, indent=2))
