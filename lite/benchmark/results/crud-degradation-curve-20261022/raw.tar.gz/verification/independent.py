"""Run after measurements: independent input replay, truth samples and old-prefix check."""
from pathlib import Path
import csv
import hashlib
import json
import os
import sys
import statistics
os.environ.update(OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1')
import numpy as np

root = Path('/home/ubuntu/project/pr2926-crud-curve-20261022')
raw = root / 'results'
sys.path.insert(0, '/home/ubuntu/project/vsag-pr2926-report-20261019/lite/benchmark')
from verify_mixed_cpu_acceptance import verify
from run_mixed_cpu_acceptance import sha
identity = json.loads((raw/'identity.json').read_text())
assert identity['library_sha256'] == '726c23082f0f0ac1a45ec8693e8a5d702ee78cadf089f23a57ae54b75f78b1ff'
assert identity['configuration']['checkpoint_every'] == 10
audit = verify(raw)
oldroot = Path('/home/ubuntu/project/pr2926-extended-resident-20261020/results')
oldrows = json.loads((oldroot/'rows.json').read_text())
rows = json.loads((raw/'rows.json').read_text())
for row in rows:
    old = next(r for r in oldrows if r['storage'] == row['storage'] and r['trial'] == 0)
    assert row['snapshots'] == old['snapshots']
    folder = f"GIST-{row['storage']}-0"
    assert (raw/folder/'quality.csv').read_bytes() == (oldroot/folder/'quality.csv').read_bytes()

def read_rows(path):
    with path.open('rb') as stream:
        dim = int.from_bytes(stream.read(4), 'little', signed=True)
    dtype = np.dtype([('dim', '<i4'), ('vector', '<f4', (dim,))])
    data = np.fromfile(path, dtype=dtype)
    assert (data['dim'] == dim).all() and np.isfinite(data['vector']).all()
    return data['vector'].copy()

inputs = identity['inputs']['GIST']
for entry in inputs.values():
    assert sha(Path(entry['path'])) == entry['sha256']
base = read_rows(Path(inputs['base.fvecs']['path']))
original = base.copy()
queries = read_rows(Path(inputs['queries.fvecs']['path']))
assert base.shape == (10000, 960) and queries.shape == (1000, 960)
sample_queries = [0, 1, 2, 5, 11, 29, 97, 313, 617, 999]
curve = []
checked = 0
updated = set()
for number in range(101):
    if number:
        for cycle in range(250):
            identifier = ((number-1)*65537 + cycle*8191) % len(base)
            donor = (identifier + number*97 + cycle + 1) % len(base)
            # Separate float32 operations match the published no-fast-math recipe.
            base[identifier] = np.float32(.875)*base[identifier] + np.float32(.125)*original[donor]
            updated.add(identifier)
    if number % 10:
        continue
    truth_by_mode = []
    for row in rows:
        folder = raw / f"GIST-{row['storage']}-0"
        with (folder/f'checkpoint-{number}-neighbors.csv').open() as stream:
            neighbors = list(csv.DictReader(stream))
        if number == 0:
            assert all(r['maintained_id'] == r['fresh_id'] and
                       r['maintained_distance'] == r['fresh_distance'] for r in neighbors)
        truth_by_mode.append([int(r['truth_id']) for r in neighbors])
        cell = row['checkpoints'][str(number)]
        state = row['states'][number]
        with (folder/'samples.csv').open() as stream:
            samples = [r for r in csv.DictReader(stream) if int(r['round']) <= number
                       and int(r['round']) > max(0, number-10) and r['operation'] == 'query']
        if samples:
            ordered = sorted(float(r['wall_us']) for r in samples)
            p50 = ordered[(len(ordered)-1)//2]
            p99 = ordered[max(1, int(np.ceil(len(ordered)*.99)))-1]
        else:
            p50 = p99 = None
        curve.append(dict(round=number, mutation_calls=number*750, updated_ids=len(updated),
            storage=row['storage'], maintained_recall=cell['maintained_recall'],
            fresh_recall=cell['fresh_recall'], rss_before_persistence_kib=int(state['rss_before_persistence_kib']),
            parent_peak_kib=int(state['peak_kib']), snapshot_bytes=int(state['snapshot_bytes']),
            preceding_10_round_query_p50_us=p50, preceding_10_round_query_p99_us=p99))
    assert truth_by_mode[0] == truth_by_mode[1] == truth_by_mode[2]
    for q in sample_queries:
        delta = base.astype(np.float64) - queries[q].astype(np.float64)
        distances = np.einsum('ij,ij->i', delta, delta, optimize=False)
        expected = np.lexsort((np.arange(len(base)), distances))[:10].tolist()
        assert expected == truth_by_mode[0][q*10:(q+1)*10], (number, q)
        checked += 1

with (root/'curve.csv').open('w', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(curve[0]))
    writer.writeheader()
    writer.writerows(curve)
(root/'curve.json').write_text(json.dumps(curve, indent=2)+'\n')
result = dict(audit=audit, initial_final_quality_matches_E12=True,
    all_300_snapshot_hashes_and_sizes_match_E12=True,
    all_33000_checkpoint_truth_top10_rows_equal_across_storage=True,
    independent_numpy_FP64_query_states=checked,
    independent_scope='10 prespecified queries at all 11 checkpoints, all 10000 current vectors; not all 11000 truth queries',
    all_checkpoint_query_intersections_recomputed=True,
    unique_updated_ids=len(updated), curve_csv_sha256=sha(root/'curve.csv'),
    no_production_patch=True, no_durability_or_zero_fragmentation_claim=True)
(root/'independent-audit.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
print([(r['round'],r['storage'],r['maintained_recall'],r['fresh_recall']) for r in curve])
