"""Measure hits only after the uninstrumented timed matrix has finished."""
from pathlib import Path
import json, time

done = Path('/home/ubuntu/project/pr2926-repair-cache4096-20261025/completed.json')
deadline = time.monotonic() + 1800
while not done.exists():
    assert time.monotonic() < deadline, 'Timed experiment did not finish'
    time.sleep(5)
assert json.loads(done.read_text())['status'] == 'PASS'
source = Path('/home/ubuntu/project/repair-cost-diagnostic-20261025.py').read_text()
source = source.replace('pr2926-repair-cost-diagnostic-20261025', 'pr2926-repair-cost4096-diagnostic-20261025')
source = source.replace('pr2926-repair-cache-20261023', 'pr2926-repair-cache4096-20261025')
source = source.replace("[('r2',pilot/'graph_backend.cpp'),('cache',cache/'graph_backend.cpp')]", "[('cache',cache/'graph_backend.cpp')]")
source = source.replace("for side in ['r2','cache']:", "for side in ['cache']:")
source = source.replace("status='PASS',runs=6", "status='PASS',runs=3")
exec(compile(source, __file__, 'exec'))
