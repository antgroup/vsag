"""Private non-timing comparison diagnostics; no repository source mutation."""
from pathlib import Path
import csv,hashlib,json,os,shlex,subprocess,tempfile,time
repo=Path('/home/ubuntu/project/vsag-pr2926-report-20261019')
scope=Path('/home/ubuntu/project/pr2926-community-scope-20261022')
pilot=Path('/home/ubuntu/project/pr2926-repair-pilot-r2-20261023')
cache=Path('/home/ubuntu/project/pr2926-repair-cache-20261023')
build=scope/'reproduction/source-bound-build'
root=Path('/home/ubuntu/project/pr2926-repair-cost-diagnostic-20261025');root.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()=='71357024f693b67ea9fc0c44d961e79a94b9f034'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1'}
commands=[]
def run(tag,argv,extra=None):
    t=time.monotonic()
    with (root/(tag+'.log')).open('w') as stream:
        p=subprocess.run(argv,cwd=repo,env={**env,**(extra or {})},stdout=stream,stderr=subprocess.STDOUT)
    commands.append(dict(tag=tag,argv=list(map(str,argv)),exit=p.returncode,seconds=time.monotonic()-t))
    (root/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(tag,p.returncode,flush=True)
    assert p.returncode==0,tag
diag='''#include <iostream>
#include <unordered_set>
namespace vsag_repair_cost_diagnostic {
bool enabled = false;
uint64_t repairs=0, rows=0, candidate_total=0, comparisons=0, common_comparisons=0;
uint64_t repeated_common=0, cache_calls=0, cache_hits=0, query_distance=0;
std::array<uint64_t,65> rejected{};
std::array<uint64_t,129> candidate_hist{};
std::unordered_set<uint64_t> seen_common;
}
extern "C" void VSAGExperimentReset() { vsag_repair_cost_diagnostic::enabled = true; }
extern "C" void VSAGExperimentDump() {
    namespace d=vsag_repair_cost_diagnostic;
    d::enabled=false;
    std::cout << "COST {\\"repairs\\":" << d::repairs << ",\\"rows\\":" << d::rows
      << ",\\"candidate_total\\":" << d::candidate_total << ",\\"comparisons\\":" << d::comparisons
      << ",\\"common_comparisons\\":" << d::common_comparisons << ",\\"repeated_common\\":" << d::repeated_common
      << ",\\"cache_calls\\":" << d::cache_calls << ",\\"cache_hits\\":" << d::cache_hits
      << ",\\"query_distance\\":" << d::query_distance << ",\\"rejected_at\\":[";
    for(uint64_t i=0;i<d::rejected.size();++i) { if(i!=0) std::cout << ','; std::cout << d::rejected[i]; }
    std::cout << "],\\"candidate_hist\\":[";
    for(uint64_t i=0;i<d::candidate_hist.size();++i) { if(i!=0) std::cout << ','; std::cout << d::candidate_hist[i]; }
    std::cout << "]}\\n";
}
'''
entry=next(e for e in json.loads((build/'compile_commands.json').read_text()) if e['file'].endswith('/graph_backend.cpp'))
link=subprocess.check_output(['ninja','-C',str(build),'-t','commands','vsag_lite'],text=True).splitlines()[-1]
assert link.startswith(': && ') and link.endswith(' && :')
def once(text,a,b):
    assert text.count(a)==1,a
    return text.replace(a,b)
for side,path in [('r2',pilot/'graph_backend.cpp'),('cache',cache/'graph_backend.cpp')]:
    out=root/side;out.mkdir()
    source=path.read_text()
    source=once(source,'namespace vsag::lite::detail {',diag+'\nnamespace vsag::lite::detail {')
    source=once(source,'const std::vector<uint64_t>& additional_candidates) {','''const std::vector<uint64_t>& additional_candidates) {
        namespace diagnostic = vsag_repair_cost_diagnostic;
        if(diagnostic::enabled) { ++diagnostic::repairs; diagnostic::seen_common.clear(); }
        auto common_candidates = additional_candidates;
        std::sort(common_candidates.begin(),common_candidates.end());
''')
    source=once(source,'            std::vector<uint64_t> selected;','''            if(diagnostic::enabled) {
                ++diagnostic::rows;
                diagnostic::candidate_total += ranked.size();
                ++diagnostic::candidate_hist[std::min<uint64_t>(128,ranked.size())];
            }
            std::vector<uint64_t> selected;''')
    source=once(source,'                bool accepted = true;','''                bool accepted = true;
                uint64_t compared = 0;''')
    anchor='                for (const uint64_t neighbor : selected) {'
    source=once(source,anchor,anchor+'''
                    ++compared;
                    if(diagnostic::enabled) {
                        ++diagnostic::comparisons;
                        if(std::binary_search(common_candidates.begin(),common_candidates.end(),neighbor) &&
                           std::binary_search(common_candidates.begin(),common_candidates.end(),candidate.slot)) {
                            ++diagnostic::common_comparisons;
                            const uint64_t key=(std::min(neighbor,candidate.slot)<<32)|std::max(neighbor,candidate.slot);
                            if(!diagnostic::seen_common.insert(key).second) ++diagnostic::repeated_common;
                        }
                    }
''')
    source=once(source,'                        accepted = false;','''                        if(diagnostic::enabled) ++diagnostic::rejected[compared];
                        accepted = false;''')
    if side=='cache':
        source=once(source,'            const uint64_t encoded = key + 1;','''            if(diagnostic::enabled) ++diagnostic::cache_calls;
            const uint64_t encoded = key + 1;''')
        source=once(source,'            if (keys[bucket] != encoded) {','''            if(diagnostic::enabled && keys[bucket] == encoded) ++diagnostic::cache_hits;
            if (keys[bucket] != encoded) {''')
    source=once(source,'    distance(const float* query, const std::vector<uint16_t>& encoded_query, uint64_t slot) const {','''    distance(const float* query, const std::vector<uint16_t>& encoded_query, uint64_t slot) const {
        if(vsag_repair_cost_diagnostic::enabled) ++vsag_repair_cost_diagnostic::query_distance;''')
    cpp=out/'graph_backend.cpp';cpp.write_text(source)
    run(side+'-format',['clang-format-15','--style=file:'+str(repo/'.clang-format'),'-i',str(cpp)])
    args=shlex.split(entry['command']);args[args.index('-o')+1]=str(out/'candidate.o');args[-1]=str(cpp)
    run(side+'-compile',args)
    args=shlex.split(link[5:-5]);args[args.index('-o')+1]=str(out/'libvsag-lite.so')
    for i,arg in enumerate(args):
        if arg.endswith('graph_backend.cpp.o'):args[i]=str(out/'candidate.o')
        elif arg.endswith('.o'):args[i]=str(build/arg)
    run(side+'-link',args)
probe=Path('/home/ubuntu/project/pr2926-repair-counts-20261023/probe.cpp')
run('probe-compile',['c++','-std=c++17','-O3','-DNDEBUG','-Wall','-Wextra','-Wpedantic','-I'+str(repo/'include'),str(probe),'-L'+str(build),'-Wl,-rpath,'+str(build),'-lvsag-lite','-ldl','-o',str(root/'probe')])
(root/'probe.cpp').write_bytes(probe.read_bytes())
expected=json.loads(Path('/home/ubuntu/project/pr2926-repair-counts-20261023/rows.json').read_text())
rows=[]
for mode in ['update','replace','reinsert']:
    for side in ['r2','cache']:
        tag=mode+'-'+side
        with tempfile.TemporaryDirectory(prefix='vsag-repair-cost-diag-',dir='/dev/shm') as directory:
            folder=Path(directory)/'output'
            run(tag,['taskset','-c','0',str(root/'probe'),'/home/ubuntu/project/pr2926-three-dataset-resident-20261019/prepared/GIST/scale-10000',str(folder),mode,'100','250','fp32'],{'LD_LIBRARY_PATH':str(root/side)})
            counts=json.loads(next(line[5:] for line in (root/(tag+'.log')).read_text().splitlines() if line.startswith('COST ')))
            final=sha(folder/'final.snapshot')
            assert final==next(r['final_snapshot_sha256'] for r in expected if r['workload']==mode and r['side']=='r2')
            for name in ['mutation-time.csv']:(root/(tag+'-'+name)).write_bytes((folder/name).read_bytes())
            rows.append(dict(mode=mode,side=side,counts=counts,final_snapshot_sha256=final,exact_r2=True))
            (root/'rows.json').write_text(json.dumps(rows,indent=2)+'\n')
            print(tag,counts['comparisons'],counts['common_comparisons'],counts['repeated_common'],counts['cache_hits'],flush=True)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
(root/'completed.json').write_text(json.dumps(dict(status='PASS',runs=6,not_timing=True,rows=rows),indent=2)+'\n')
