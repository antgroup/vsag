"""Three predeclared fresh-process mixed pairs, even if reuse does not win."""
from pathlib import Path
import csv, hashlib, json, os, shutil, subprocess, sys, tempfile, time

repo=Path('/home/ubuntu/project/vsag-pr2926-report-20261019')
scope=Path('/home/ubuntu/project/pr2926-community-scope-20261022')
pilot=Path('/home/ubuntu/project/pr2926-repair-pilot-r2-20261023')
candidate=Path('/home/ubuntu/project/pr2926-repair-scratch-reuse-20261025')
root=Path('/home/ubuntu/project/pr2926-repair-reuse-mixed-20261025')
data=Path('/home/ubuntu/project/pr2926-three-dataset-resident-20261019/prepared/GIST/scale-10000')
parent='71357024f693b67ea9fc0c44d961e79a94b9f034'
deadline=time.monotonic()+3600
while not (candidate/'completed.json').exists():
    assert time.monotonic()<deadline
    time.sleep(5)
assert json.loads((candidate/'completed.json').read_text())['status']=='PASS'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==parent
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
root.mkdir(exist_ok=False)
sys.path.insert(0,str(repo/'lite/benchmark'))
from run_mixed_cpu_acceptance import sha, verify_run, verify_checkpoints
def write(name,value): (root/name).write_text(json.dumps(value,indent=2)+'\n')
env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1'}
commands=[]
def run(tag,argv,extra=None):
    started=time.monotonic()
    with (root/(tag+'.log')).open('w') as stream:
        result=subprocess.run(argv,cwd=repo,env={**env,**(extra or {})},stdout=stream,stderr=subprocess.STDOUT)
    commands.append(dict(tag=tag,argv=list(map(str,argv)),exit=result.returncode,seconds=time.monotonic()-started))
    write('commands.json',commands)
    print(tag,result.returncode,flush=True)
    assert result.returncode==0,tag
build=scope/'reproduction/source-bound-build'
source=repo/'lite/benchmark/mixed_cpu_acceptance.cpp'
shutil.copy2(source,root/'source.cpp')
probe=root/'probe'
run('probe-compile',['c++','-std=c++17','-O3','-DNDEBUG','-Wall','-Wextra','-Wpedantic',
    '-I'+str(repo/'include'),str(root/'source.cpp'),'-L'+str(build),'-Wl,-rpath,'+str(build),'-lvsag-lite','-o',str(probe)])
libs={'r2':pilot/'libvsag-lite.so','reuse':candidate/'release/libvsag-lite.so'}
assert sha(libs['r2'])=='967a0f5a4ab17019b04ab5e7cdc6e5b3e12e81df0655927eea77aac612b1387f'
assert sha(libs['reuse'])==json.loads((candidate/'identity.json').read_text())['cache_library_sha256']
write('identity.json',dict(schema='private-experimental-mixed-v2',parent=parent,
    source_sha256=sha(source),probe_sha256=sha(probe),
    libraries={s:dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size) for s,p in libs.items()},
    inputs={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in [data/'base.fvecs',data/'queries.fvecs']},
    configuration=dict(dataset='GIST10k',dimension=960,storage='fp32',query_rows=1000,distinct_query_rows=998,
        degree=16,ef_construction=128,ef_search=512,k=10,cpu=0,threads=1,rounds=100,cycles=250,checkpoint_every=25,
        resident=True,mutation_mode='all',trials=3),
    boundary='Only private r2 versus temporary-capacity reuse. All repeats retained; no threshold, FP16/RaBitQ or hour-scale claim. Explicit tmpfs Save/Load, not crash durability.'))
write('plan.json',dict(pairs=[dict(trial=t,order=['r2','reuse'] if t%2==0 else ['reuse','r2']) for t in range(3)],
    rationale='Fixed before first mixed run. Execute all pairs regardless of pure-loop speed. Median of process metrics, not fastest run or pooled quantiles.'))
rows=[]
for trial in range(3):
    pair=[]
    for side in (['r2','reuse'] if trial%2==0 else ['reuse','r2']):
        lib=libs[side]
        tag=f'{trial}-{side}'
        output=root/tag
        extra={'LD_LIBRARY_PATH':str(lib.parent)}
        binding=subprocess.check_output(['ldd',str(probe)],env={**env,**extra},text=True)
        assert str(lib) in binding
        (root/(tag+'-ldd.log')).write_text(binding)
        assert shutil.disk_usage('/dev/shm').free>5*1024**3
        with tempfile.TemporaryDirectory(prefix='vsag-repair-reuse-mixed-20261025-',dir='/dev/shm') as directory:
            argv=['taskset','-c','0',str(probe),str(data),str(output),'fp32','100','250',directory,'resident','25']
            write(tag+'-command.json',dict(argv=argv,**extra))
            print('START',tag,flush=True)
            run(tag,argv,extra)
            row=verify_run(output,100,250,1000)
            row['checkpoints']=verify_checkpoints(output,100,250,1000,25)
            assert all(int(s['threads'])==1 and int(s['proc_hwm_kib'])>0 for s in row['states'])
            snapshots={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(Path(directory).iterdir())}
            assert set(snapshots)=={'round-'+str(n) for n in range(1,101)}
            row.update(side=side,trial=trial,folder=tag,snapshots=snapshots)
            rows.append(row);pair.append(row);write('rows.json',rows)
        print('PASS',tag,row['recall'],flush=True)
    assert pair[0]['snapshots']==pair[1]['snapshots']
    for name in ['quality.csv']+[f'checkpoint-{n}-neighbors.csv' for n in [0,25,50,75,100]]:
        assert (root/pair[0]['folder']/name).read_bytes()==(root/pair[1]['folder']/name).read_bytes(),name
assert len({json.dumps(r['snapshots'],sort_keys=True) for r in rows})==1
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
write('completed.json',dict(status='PASS',processes=6,mutation_calls=450000,interleaved_queries=450000,
    save_load_pairs=600,roundtrip_query_pairs=600000,checkpoints=30,all_graphs_exact_r2=True,
    source_unchanged=True,quality_threshold=None))
