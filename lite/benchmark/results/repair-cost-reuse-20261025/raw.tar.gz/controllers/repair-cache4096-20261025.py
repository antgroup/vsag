"""Private capacity experiment: retain original control flow and all failed evidence."""
from pathlib import Path
import hashlib, json, subprocess

repo = Path('/home/ubuntu/project/vsag-pr2926-report-20261019')
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == '71357024f693b67ea9fc0c44d961e79a94b9f034'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo)
diagnostic = Path('/home/ubuntu/project/pr2926-repair-cost-diagnostic-20261025/completed.json')
assert json.loads(diagnostic.read_text())['status'] == 'PASS'
original = Path('/home/ubuntu/project/crud-repair-cache-20261023.py').read_text()
source = original.replace('pr2926-repair-cache-20261023', 'pr2926-repair-cache4096-20261025')
source = source.replace('vsag-repair-cache-20261023-', 'vsag-repair-cache4096-20261025-')
assert source.count('std::array<uint64_t, 256>') == 1
assert source.count('std::array<float, 256>') == 1
assert source.count('>> 56;') == 1
source = source.replace('std::array<uint64_t, 256>', 'std::array<uint64_t, 4096>')
source = source.replace('std::array<float, 256>', 'std::array<float, 4096>')
source = source.replace('>> 56;', '>> 52;').replace('cache_entries=256', 'cache_entries=4096')
source = source.replace("probe='#include <sys/resource.h>\\n'+probe", "assert probe.count('#include <sys/resource.h>') == 1")
source = source.replace("parent='cec5b915fb1ab3d21fd7997749bad58c43ae497b'", "parent='71357024f693b67ea9fc0c44d961e79a94b9f034'")
exec(compile(source, __file__, 'exec'))
