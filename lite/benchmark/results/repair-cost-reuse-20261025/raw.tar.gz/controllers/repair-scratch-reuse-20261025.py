"""Independent exact-policy candidate; do not combine it with the cache experiment."""
from pathlib import Path
import subprocess, shlex, json, os, time, hashlib, difflib, tempfile, csv

repo = Path('/home/ubuntu/project/vsag-pr2926-report-20261019')
scope = Path('/home/ubuntu/project/pr2926-community-scope-20261022')
pilot = Path('/home/ubuntu/project/pr2926-repair-pilot-r2-20261023')
build = scope/'reproduction/source-bound-build'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
done = Path('/home/ubuntu/project/pr2926-repair-cost4096-diagnostic-20261025/completed.json')
deadline = time.monotonic()+2400
while not done.exists():
    assert time.monotonic()<deadline
    time.sleep(5)
assert json.loads(done.read_text())['status']=='PASS'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()=='71357024f693b67ea9fc0c44d961e79a94b9f034'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
assert sha(pilot/'graph_backend.cpp')=='a4cc79be004315a9c1004d40dc0dd7e0a2ea76a413a0edafca3aec2069bd9c97'
root = Path('/home/ubuntu/project/pr2926-repair-scratch-reuse-20261025')
root.mkdir(exist_ok=False)
source = (pilot/'graph_backend.cpp').read_text()
start=source.index('    void\n    repair(')
stop=source.index('\n    template <typename T>',start)
body=source[start:stop]
def once(a,b):
    global body
    assert body.count(a)==1,a
    body=body.replace(a,b)
once('        auto targets = affected_nodes;', '''        // Reuse temporary capacity only within this repair; no cross-operation state.
        std::vector<uint64_t> candidates;
        std::vector<Candidate> ranked;
        std::vector<uint64_t> selected;
        selected.reserve(max_degree_);
        auto targets = affected_nodes;''')
once('            const auto old_neighbors = extras_[source];','            const auto& old_neighbors = extras_[source];')
once('            auto candidates = old_neighbors;', '            candidates = old_neighbors;')
once('            std::vector<Candidate> ranked;', '            ranked.clear();')
once('            std::vector<uint64_t> selected;\n            selected.reserve(max_degree_);', '            selected.clear();')
cpp=root/'graph_backend.cpp'
cpp.write_text(source[:start]+body+source[stop:])
original=Path('/home/ubuntu/project/crud-repair-cache-20261023.py').read_text()
tail=original[original.index('commands=[];env='):]
tail=tail.replace('pr2926-repair-cache-20261023','pr2926-repair-scratch-reuse-20261025')
tail=tail.replace('vsag-repair-cache-20261023-','vsag-repair-scratch-reuse-20261025-')
tail=tail.replace("probe='#include <sys/resource.h>\\n'+probe", "assert probe.count('#include <sys/resource.h>') == 1")
tail=tail.replace("parent='cec5b915fb1ab3d21fd7997749bad58c43ae497b'", "parent='71357024f693b67ea9fc0c44d961e79a94b9f034'")
tail=tail.replace('cache_entries=256','cache_entries=0, candidate_kind="temporary-capacity-reuse"')
tail=tail.replace('One-repair cache only; direct-map replacement cannot change calculated values; no source/API/default changes',
    'Temporary candidates/ranked/selected capacity reused only inside repair; old adjacency read by reference until replacement; no distance, selection, journal or default-source change')
exec(compile(tail,__file__,'exec'))
