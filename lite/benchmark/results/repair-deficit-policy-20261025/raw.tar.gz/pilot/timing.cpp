// Copyright 2024-present the vsag project
// SPDX-License-Identifier: Apache-2.0
#include <sys/resource.h>
#include <sys/wait.h>
#include <unistd.h>
#include <vsag/lite/index.h>

#include <algorithm>
#include <cerrno>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace {
using Rows = std::vector<std::vector<float>>;

void
require(bool value, const char* message) {
    if (not value) {
        throw std::runtime_error(message);
    }
}

Rows
read_rows(const std::string& path) {
    std::ifstream input(path, std::ios::binary);
    require(static_cast<bool>(input), "open fvecs failed");
    Rows rows;
    int32_t first_dim = 0;
    while (input.peek() != std::char_traits<char>::eof()) {
        int32_t dim = 0;
        input.read(reinterpret_cast<char*>(&dim), sizeof(dim));
        require(static_cast<bool>(input) and dim > 0 and dim <= 4096, "invalid dimension");
        if (rows.empty()) {
            first_dim = dim;
        }
        require(dim == first_dim, "dimension mismatch");
        std::vector<float> row(dim);
        input.read(reinterpret_cast<char*>(row.data()),
                   static_cast<std::streamsize>(dim * sizeof(float)));
        require(static_cast<bool>(input), "truncated row");
        for (float value : row) {
            require(std::isfinite(value), "nonfinite input");
        }
        rows.push_back(std::move(row));
    }
    require(not rows.empty(), "empty input");
    return rows;
}
std::vector<int64_t>
truth(const Rows& base, const std::vector<float>& query, uint64_t k) {
    std::vector<std::pair<double, int64_t>> distances;
    distances.reserve(base.size());
    for (uint64_t id = 0; id < base.size(); ++id) {
        double distance = 0;
        for (uint64_t d = 0; d < query.size(); ++d) {
            const double delta = static_cast<double>(base[id][d]) - query[d];
            distance += delta * delta;
        }
        distances.emplace_back(distance, static_cast<int64_t>(id));
    }
    std::partial_sort(
        distances.begin(), distances.begin() + static_cast<int64_t>(k), distances.end());
    std::vector<int64_t> result;
    for (uint64_t rank = 0; rank < k; ++rank) {
        result.push_back(distances[rank].second);
    }
    return result;
}

void
validate(const std::vector<vsag::lite::Neighbor>& neighbors,
         const std::vector<bool>& live,
         uint64_t k) {
    require(neighbors.size() == k, "result size changed");
    std::vector<int64_t> ids;
    for (const auto& neighbor : neighbors) {
        require(neighbor.id >= 0 and static_cast<uint64_t>(neighbor.id) < live.size() and
                    live[neighbor.id] and std::isfinite(neighbor.distance),
                "dead, invalid or nonfinite result");
        ids.push_back(neighbor.id);
    }
    std::sort(ids.begin(), ids.end());
    require(std::adjacent_find(ids.begin(), ids.end()) == ids.end(), "duplicate result");
    require(std::is_sorted(neighbors.begin(),
                           neighbors.end(),
                           [](const auto& a, const auto& b) {
                               return a.distance < b.distance or
                                      (a.distance == b.distance and a.id < b.id);
                           }),
            "unordered results");
}

void
run(int argc, char** argv) {
    require(argc == 7, "usage: slot-control DATASET OUTPUT MODE ROUNDS CYCLES");
    const std::string mode(argv[3]);
    require(mode == "replace" or mode == "reinsert" or mode == "update", "invalid mode");
    const std::string storage(argv[6]);
    require(storage == "fp32" or storage == "fp16", "invalid storage");
    const auto format =
        storage == "fp32" ? vsag::lite::VectorStorage::FP32 : vsag::lite::VectorStorage::FP16;
    const uint64_t rounds = std::stoull(argv[4]);
    const uint64_t cycles = std::stoull(argv[5]);
    require(rounds > 0 and cycles > 0 and rounds <= 1000000 and cycles <= 1000000 and
                rounds * cycles <= 1000000,
            "invalid schedule");
    const std::filesystem::path output(argv[2]);
    require(not std::filesystem::exists(output), "output already exists");
    auto base = read_rows(std::string(argv[1]) + "/base.fvecs");
    const auto original = base;
    const auto queries = read_rows(std::string(argv[1]) + "/queries.fvecs");
    const uint64_t count = base.size();
    const uint64_t dim = base.front().size();
    require(count > 10 and queries.front().size() == dim, "invalid data");
    std::filesystem::create_directory(output);
    std::vector<uint64_t> canonical_order(count);
    std::vector<uint64_t> order(count);
    std::vector<uint64_t> slots(count);
    for (uint64_t id = 0; id < count; ++id) {
        canonical_order[id] = order[id] = slots[id] = id;
    }
    const auto build = [&](const std::vector<uint64_t>& sequence) {
        auto created = vsag::lite::Index::Create(dim);
        require(static_cast<bool>(created), "create failed");
        auto index = std::move(*created);
        for (const uint64_t id : sequence) {
            require(static_cast<bool>(index->Add(static_cast<int64_t>(id), base[id].data(), dim)),
                    "build add failed");
        }
        require(static_cast<bool>(index->BuildGraph(format, 16, 128)), "build graph failed");
        return index;
    };
    auto maintained = build(canonical_order);
    {
        std::ofstream initial(output / "initial.snapshot", std::ios::binary);
        require(static_cast<bool>(maintained->Save(initial)), "initial save failed");
        initial.close();
        require(static_cast<bool>(initial), "initial snapshot failed");
    }
    rusage before{};
    require(getrusage(RUSAGE_SELF, &before) == 0, "getrusage failed");
    const auto mutation_start = std::chrono::steady_clock::now();
    for (uint64_t round = 1; round <= rounds; ++round) {
        for (uint64_t cycle = 0; cycle < cycles; ++cycle) {
            const uint64_t id = ((round - 1) * 65537ULL + cycle * 8191ULL) % count;
            const uint64_t donor = (id + round * 97 + cycle + 1) % count;
            auto replacement = base[id];
            if (mode != "reinsert") {
                for (uint64_t d = 0; d < dim; ++d) {
                    replacement[d] = 0.875F * base[id][d] + 0.125F * original[donor][d];
                }
                require(replacement != base[id], "replacement unchanged");
            }
            if (mode == "update") {
                require(static_cast<bool>(
                            maintained->Update(static_cast<int64_t>(id), replacement.data(), dim)),
                        "update failed");
            } else {
                require(maintained->Remove(static_cast<int64_t>(id)), "remove failed");
                const uint64_t position = slots[id];
                const uint64_t moved = order.back();
                order[position] = moved;
                slots[moved] = position;
                order.pop_back();
                require(static_cast<bool>(
                            maintained->Add(static_cast<int64_t>(id), replacement.data(), dim)),
                        "readd failed");
            }
            base[id] = replacement;
            if (mode != "update") {
                slots[id] = order.size();
                order.push_back(id);
            }
        }
    }
    const auto mutation_end = std::chrono::steady_clock::now();
    std::ofstream mutation_time(output / "mutation-time.csv");
    mutation_time
        << "calls,wall_ms\n"
        << std::setprecision(17) << rounds * cycles * (mode == "update" ? 1 : 2) << ','
        << std::chrono::duration<double, std::milli>(mutation_end - mutation_start).count() << '\n';
    mutation_time.close();
    require(static_cast<bool>(mutation_time), "mutation timing write failed");
    rusage after{};
    require(getrusage(RUSAGE_SELF, &after) == 0, "getrusage failed");
    const auto seconds = [](const timeval& value) {
        return static_cast<double>(value.tv_sec) + static_cast<double>(value.tv_usec) / 1000000.0;
    };
    std::ofstream cpu(output / "cpu.csv");
    cpu << "user_s,system_s\n"
        << std::setprecision(17) << seconds(after.ru_utime) - seconds(before.ru_utime) << ','
        << seconds(after.ru_stime) - seconds(before.ru_stime) << '\n';
    cpu.close();
    require(static_cast<bool>(cpu), "CPU output failed");
    std::ofstream snapshot(output / "final.snapshot", std::ios::binary);
    require(static_cast<bool>(maintained->Save(snapshot)), "final save failed");
    snapshot.close();
    require(static_cast<bool>(snapshot), "snapshot write failed");
}
}  // namespace
int
main(int argc, char** argv) {
    try {
        run(argc, argv);
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
