"""Private remote-only graph-changing experiment; never edits production source."""
from pathlib import Path
import csv, difflib, hashlib, json, math, os, shlex, statistics, struct, subprocess, tempfile, time

base = Path('/home/ubuntu/project')
repo = base/'vsag-pr2926-report-20261019'
scope = base/'pr2926-community-scope-20261022'
pilot = base/'pr2926-repair-pilot-r2-20261023'
root = base/'pr2926-repair-deficit-policy-20261025'
parent = 'bbc5b94bd46b3c682852df4effec423bcc5d879a'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==parent
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
root.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(pilot/'graph_backend.cpp')=='a4cc79be004315a9c1004d40dc0dd7e0a2ea76a413a0edafca3aec2069bd9c97'
env = {**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1'}
commands = []
def run(tag, args, extra=None):
    start = time.monotonic()
    with (root/(tag+'.log')).open('w') as stream:
        result = subprocess.run(list(map(str,args)),cwd=repo,env={**env,**(extra or {})},stdout=stream,stderr=subprocess.STDOUT)
    commands.append(dict(tag=tag,argv=list(map(str,args)),exit=result.returncode,seconds=time.monotonic()-start))
    (root/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    print(tag,result.returncode,flush=True)
    assert result.returncode==0,tag

source = (pilot/'graph_backend.cpp').read_text()
anchor = '            targets.insert(targets.end(), old_neighbors.begin(), old_neighbors.end());\n'
assert source.count(anchor)==1
cpp=root/'graph_backend.cpp'
cpp.write_text(source.replace(anchor,anchor+'''            // Isolated policy pilot: keep full rows, reselect only degree-deficit rows.
            // Incoming protection below still runs for every affected row and old target.
            if (old_neighbors.size() == std::min(max_degree_, Size() - 1)) {
                continue;
            }
'''))
run('format',['clang-format-15','--style=file:'+str(repo/'.clang-format'),'-i',cpp])
(root/'candidate.diff').write_text(''.join(difflib.unified_diff(source.splitlines(True),cpp.read_text().splitlines(True),fromfile='a/r2/graph_backend.cpp',tofile='b/deficit/graph_backend.cpp')))
build=scope/'reproduction/source-bound-build'
for config,path in [('release',build),('san',scope/'sanitizer')]:
    out=root/config;out.mkdir()
    entry=next(e for e in json.loads((path/'compile_commands.json').read_text()) if e['file'].endswith('/graph_backend.cpp'))
    args=shlex.split(entry['command']);args[args.index('-o')+1]=str(out/'candidate.o');args[-1]=str(cpp)
    run(config+'-compile',args)
    if config=='release':
        run('tidy',['clang-tidy-15',cpp,'--config-file='+str(repo/'.clang-tidy'),'--header-filter=.*/pr2926-repair-deficit-policy-20261025/.*','--',*shlex.split(entry['command'])[1:shlex.split(entry['command']).index('-o')]])
    link=subprocess.check_output(['ninja','-C',str(path),'-t','commands','vsag_lite'],text=True).splitlines()[-1]
    assert link.startswith(': && ') and link.endswith(' && :')
    args=shlex.split(link[5:-5]);args[args.index('-o')+1]=str(out/'libvsag-lite.so')
    for i,arg in enumerate(args):
        if arg.endswith('graph_backend.cpp.o'): args[i]=str(out/'candidate.o')
        elif arg.endswith('.o'): args[i]=str(path/arg)
    run(config+'-link',args)
    suite=scope/('release-on' if config=='release' else 'sanitizer')
    extra={'LD_LIBRARY_PATH':str(out)}
    if config=='san': extra.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    run(config+'-ldd',['ldd',suite/'lite_graph_tests'],extra)
    assert str(out/'libvsag-lite.so') in (root/(config+'-ldd.log')).read_text()
    run(config+'-ctest',['ctest','--test-dir',suite,'--output-on-failure'],extra)

# Reuse the established independent FP64 truth and same-current-data rebuild protocol.
quality_source=base/'pr2926-repair-followup-20261023/probe.cpp'
probe_text=quality_source.read_text()
anchor='    std::ofstream mapping(output / "slots.csv");'
assert probe_text.count(anchor)==1
probe_text=probe_text.replace(anchor,'''    std::ifstream saved(output / "maintained.snapshot", std::ios::binary);
    auto loaded = vsag::lite::Index::Load(saved);
    require(static_cast<bool>(loaded), "reload failed");
'''+anchor)
anchor='                validate(found[side], live, 10);'
assert probe_text.count(anchor)==1
probe_text=probe_text.replace(anchor,anchor+'''
                if (side == 0) {
                    auto restored = (*loaded)->SearchWithOptions(queries[q].data(), dim, 10, {ef});
                    require(static_cast<bool>(restored), "reloaded query failed");
                    validate(*restored, live, 10);
                    for (uint64_t rank = 0; rank < 10; ++rank) {
                        require((*restored)[rank].id == found[side][rank].id and
                                    (*restored)[rank].distance == found[side][rank].distance,
                                "save/load result mismatch");
                    }
                }
''')
quality_cpp=root/'quality.cpp';quality_cpp.write_text(probe_text)
run('quality-format',['clang-format-15','--style=file:'+str(repo/'.clang-format'),'-i',quality_cpp])
run('quality-tidy',['clang-tidy-15',quality_cpp,'--config-file='+str(repo/'.clang-tidy'),'--header-filter=.*/pr2926-repair-deficit-policy-20261025/.*','--','-std=c++17','-I'+str(repo/'include')])
for config in ['release','san']:
    args=['c++','-std=c++17','-O3' if config=='release' else '-O1','-g','-DNDEBUG','-Wall','-Wextra','-Wpedantic','-I'+str(repo/'include'),str(quality_cpp),'-L'+str(root/config),'-Wl,-rpath,'+str(root/config),'-lvsag-lite','-o',str(root/('quality-'+config))]
    if config=='san': args[1:1]=['-fsanitize=address,undefined','-fno-omit-frame-pointer']
    run('quality-'+config+'-compile',args)

data=base/'pr2926-three-dataset-resident-20261019/prepared/GIST/scale-10000'
assert sha(data/'base.fvecs')=='359290ad0de501d683122967de2b353ecd6522b0ffc630c59ca945e228fd5444'
assert sha(data/'queries.fvecs')=='0d1d620049de12da455ed7201e97cbab372c4d54d0e6dedbc8c503f62c911299'
small=root/'san-data';small.mkdir()
for name,count in [('base.fvecs',128),('queries.fvecs',20)]:
    original=data/name
    with original.open('rb') as stream:
        dim=struct.unpack('<i',stream.read(4))[0];stream.seek(0)
        (small/name).write_bytes(stream.read((4+dim*4)*count))
for mode in ['update','replace','reinsert']:
    run('san-quality-'+mode,[root/'quality-san',small,root/('san-'+mode),mode,'2','16','fp32'],{'LD_LIBRARY_PATH':str(root/'san'),'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'})

timing_cpp=base/'pr2926-repair-cache-20261023/probe.cpp'
assert sha(timing_cpp)=='ccb3ba819f9f49f073d7ebf96c26e41616de8f03dcf9efba459e3211ce1f534d'
(root/'timing.cpp').write_bytes(timing_cpp.read_bytes())
run('timing-compile',['c++','-std=c++17','-O3','-DNDEBUG','-I'+str(repo/'include'),root/'timing.cpp','-L'+str(build),'-Wl,-rpath,'+str(build),'-lvsag-lite','-o',root/'timing'])
identity=dict(parent=parent,r2_source_sha256=sha(pilot/'graph_backend.cpp'),r2_library_sha256=sha(pilot/'libvsag-lite.so'),candidate_source_sha256=sha(cpp),candidate_library_sha256=sha(root/'release/libvsag-lite.so'),quality_probe_sha256=sha(quality_cpp),original_quality_probe_sha256=sha(quality_source),timing_probe_sha256=sha(root/'timing.cpp'),inputs={name:dict(sha256=sha(data/name),bytes=(data/name).stat().st_size) for name in ['base.fvecs','queries.fvecs']},policy='Skip only full rows after recording old targets; all incoming protections, refill for deficits, validation and journals unchanged. Graph-changing private policy, no default adoption.')
(root/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
plan=dict(dataset='GIST',count=10000,dim=960,queries=1000,distinct_queries=998,storage='fp32',rounds=100,cycles=250,degree=16,build_ef=128,query_ef=[512,10000],k=10,quality_processes=6,timing_processes=18,timing_pairs_per_mode=3,order='quality alternating; timing alternating across mode/trial',boundary='Quality runs include independent FP64 truth, same-data canonical/same-slot rebuild and Save/Load result comparison. Timing loop includes vector formula/bookkeeping; not API-only latency, no interleaved queries, no new P50/P99/RSS or durability claim.')
(root/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
def read(path):
    with path.open() as stream:return list(csv.DictReader(stream))
def snapshot(path):
    with path.open('rb') as stream:
        header=struct.unpack('<8s7Q',stream.read(64));count=header[3];dim=header[2]
        ids=stream.read(count*8);vectors=stream.read(count*dim*4)
    return dict(header=header,ids=ids,vectors=vectors,sha256=sha(path),bytes=path.stat().st_size)
quality=[]
for number,mode in enumerate(['update','replace','reinsert']):
    dirs={};snapshots={};neighbor_rows={}
    with tempfile.TemporaryDirectory(prefix='vsag-deficit-quality-',dir='/dev/shm') as directory:
        for side in (['r2','deficit'] if number%2==0 else ['deficit','r2']):
            folder=Path(directory)/side;dirs[side]=folder
            tag='quality-'+mode+'-'+side
            run(tag,['taskset','-c','0',root/'quality-release',data,folder,mode,'100','250','fp32'],{'LD_LIBRARY_PATH':str(pilot if side=='r2' else root/'release')})
            snapshots[side]={p.name:snapshot(p) for p in folder.glob('*.snapshot')}
            neighbor_rows[side]=read(folder/'neighbors.csv')
            for name in ['neighbors.csv','slots.csv','mutation-time.csv']:
                (root/(tag+'-'+name)).write_bytes((folder/name).read_bytes())
        assert snapshots['r2']['initial.snapshot']['sha256']==snapshots['deficit']['initial.snapshot']['sha256']
        a,b=[snapshots[s]['maintained.snapshot'] for s in ['r2','deficit']]
        assert a['header'][:4]==b['header'][:4] and a['header'][5:]==b['header'][5:]
        assert a['ids']==b['ids'] and a['vectors']==b['vectors'],'Stored current geometry/layout differs'
        assert (dirs['r2']/'slots.csv').read_bytes()==(dirs['deficit']/'slots.csv').read_bytes()
        for view in ['canonical','same_order']:
            assert snapshots['r2'][view+'.snapshot']['sha256']==snapshots['deficit'][view+'.snapshot']['sha256']
        values={}
        for side in dirs:
            values[side]={}
            rows=neighbor_rows[side];reference=neighbor_rows['r2'];assert len(rows)==len(reference)==20000
            assert [(r['query'],r['rank'],r['ef'],r['truth_id']) for r in rows]==[(r['query'],r['rank'],r['ef'],r['truth_id']) for r in reference]
            for view in ['canonical','same_order']:
                assert [(r[view+'_id'],r[view+'_distance']) for r in rows]==[(r[view+'_id'],r[view+'_distance']) for r in reference]
            for ef in [512,10000]:
                selected=[r for r in rows if int(r['ef'])==ef]
                hits={view:0 for view in ['maintained','canonical','same_order']}
                for q in range(1000):
                    group=selected[q*10:(q+1)*10];assert len(group)==10
                    truth={int(r['truth_id']) for r in group};assert len(truth)==10
                    for view in hits:
                        result=[(float(r[view+'_distance']),int(r[view+'_id'])) for r in group]
                        assert result==sorted(result) and len({i for _,i in result})==10
                        assert all(math.isfinite(d) and 0<=i<10000 for d,i in result)
                        hits[view]+=len(truth & {i for _,i in result})
                values[side][str(ef)]={v:h/10000 for v,h in hits.items()}
        receipts={s:{n:{k:v for k,v in item.items() if k in ['sha256','bytes']} for n,item in ss.items()} for s,ss in snapshots.items()}
        quality.append(dict(workload=mode,quality=values,snapshots=receipts,current_geometry_layout_equal=True,save_load_results_equal=True))
        (root/'quality.json').write_text(json.dumps(quality,indent=2)+'\n')
        assert json.loads((root/'quality.json').read_text())==quality
    print('QUALITY',mode,json.dumps(values),flush=True)

timing=[]
for number,(mode,trial) in enumerate((m,t) for m in ['update','replace','reinsert'] for t in range(3)):
    records=[]
    with tempfile.TemporaryDirectory(prefix='vsag-deficit-timing-',dir='/dev/shm') as directory:
        for side in (['r2','deficit'] if number%2==0 else ['deficit','r2']):
            folder=Path(directory)/side;tag=f'timing-{mode}-{trial}-{side}'
            run(tag,['taskset','-c','0',root/'timing',data,folder,mode,'100','250','fp32'],{'LD_LIBRARY_PATH':str(pilot if side=='r2' else root/'release')})
            snapshots={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in folder.glob('*.snapshot')}
            expected=next(q for q in quality if q['workload']==mode)['snapshots'][side]
            assert snapshots['initial.snapshot']==expected['initial.snapshot']
            assert snapshots['final.snapshot']==expected['maintained.snapshot'],'Repeated same-policy topology differs'
            wall=read(folder/'mutation-time.csv')[0];cpu=read(folder/'cpu.csv')[0]
            records.append(dict(workload=mode,trial=trial,side=side,loop_wall_ms=float(wall['wall_ms']),user_s=float(cpu['user_s']),system_s=float(cpu['system_s']),calls=int(wall['calls']),snapshots=snapshots))
            for name in ['mutation-time.csv','cpu.csv']:(root/(tag+'-'+name)).write_bytes((folder/name).read_bytes())
        timing.extend(records);(root/'timing.json').write_text(json.dumps(timing,indent=2)+'\n')
        assert json.loads((root/'timing.json').read_text())==timing
    print('TIMING',mode,trial,[(r['side'],r['loop_wall_ms']) for r in records],flush=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==parent
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
(root/'completed.json').write_text(json.dumps(dict(status='PASS',quality_processes=6,timing_processes=18,mutation_calls=1000000,production_unchanged=True,quality=quality,timing=timing),indent=2)+'\n')
print('COMPLETE',flush=True)
