// Private Linux diagnostic: classify and exercise actual selected kernel pointers.
#include <cxxabi.h>
#include <dlfcn.h>

#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

#ifdef FULL_SIDE
#include "simd/fp16_simd.h"
#include "simd/fp32_simd.h"
#include "simd/rabitq_simd.h"
#else
#include "lite/fp16_distance.h"
#include "lite/fp32_distance.h"
#include "lite/rabitq_filter_ip.h"
#endif

template <typename Function>
void describe(const char* label, Function function) {
    Dl_info info{};
    if (dladdr(reinterpret_cast<void*>(function), &info) == 0 || info.dli_sname == nullptr) {
        throw std::runtime_error("Cannot resolve selected kernel");
    }
    int status = 0;
    char* demangled = abi::__cxa_demangle(info.dli_sname, nullptr, nullptr, &status);
    std::cout << label << '\t' << (status == 0 ? demangled : info.dli_sname) << '\t'
              << info.dli_fname << '\n';
    std::free(demangled);
}

int main() {
#ifdef FULL_SIDE
    const auto fp32 = vsag::FP32ComputeL2Sqr;
    const auto fp16 = vsag::FP16ComputeL2Sqr;
    const auto supplement = vsag::RaBitQFloatSupplementCodeIP;
#else
    const auto fp32 = vsag::lite::detail::select_fp32_distance();
    const auto fp16 = vsag::lite::detail::select_fp16_distance();
    const auto supplement = vsag::lite::detail::rabitq::select_rabitq_supplement_ip();
#endif
    describe("fp32", fp32);
    describe("fp16", fp16);
    describe("rabitq_supplement", supplement);
    for (uint64_t dim : {128U, 960U, 768U, 129U}) {
        std::vector<float> query(dim, 0.0F), vector(dim, 0.5F), inner(dim, 0.5F);
        std::vector<uint16_t> query16(dim, 0), vector16(dim, 0x3800);
        const uint64_t plane_bytes = (dim + 7) / 8;
        std::vector<uint8_t> codes(5 * plane_bytes, 0);
        for (uint64_t d = 0; d < dim; ++d) {
            codes[d / 8] |= static_cast<uint8_t>(1U << (d % 8));
        }
        const float first = fp32(query.data(), vector.data(), dim);
#ifdef FULL_SIDE
        const float second = fp16(reinterpret_cast<const uint8_t*>(query16.data()),
                                  reinterpret_cast<const uint8_t*>(vector16.data()), dim);
        const float third = supplement(inner.data(), codes.data(), dim, 5);
#else
        const float second = fp16(query16.data(), vector16.data(), dim);
        const float third = supplement(inner.data(), codes.data(), dim);
#endif
        if (first != static_cast<float>(dim) * 0.25F || second != first ||
            third != static_cast<float>(dim) * 0.5F) {
            throw std::runtime_error("Selected kernel does not match independent exact fixture");
        }
        std::cout << "fixture\t" << dim << '\t' << first << '\t' << second << '\t' << third
                  << '\n';
    }
}
