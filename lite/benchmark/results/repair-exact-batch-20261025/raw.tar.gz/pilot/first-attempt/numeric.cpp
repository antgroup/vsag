// Copyright 2024-present the vsag project
// SPDX-License-Identifier: Apache-2.0
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <random>
#include <stdexcept>
#include <vector>

#include "lite/fp32_distance.h"
namespace vsag::lite::detail {
void
experimental_repair_batch4(const float*,
                           uint64_t,
                           const float*,
                           const float*,
                           const float*,
                           const float*,
                           float&,
                           float&,
                           float&,
                           float&);
}
uint32_t
bits(float value) {
    uint32_t result{};
    std::memcpy(&result, &value, sizeof(result));
    return result;
}
int
main() {
    using namespace vsag::lite::detail;
    if (select_fp32_distance() != avx512_fp32_distance)
        throw std::runtime_error("AVX512 dispatcher required for this numerical pilot");
    std::mt19937 generator(424242);
    std::uniform_real_distribution<float> random(-10.0F, 10.0F);
    uint64_t compared = 0;
    for (uint64_t dim : std::array<uint64_t, 17>{
             1, 15, 16, 17, 63, 64, 65, 127, 128, 129, 767, 768, 769, 959, 960, 961, 1536}) {
        for (uint64_t trial = 0; trial < 64; ++trial) {
            std::array<std::vector<float>, 5> vectors;
            for (uint64_t row = 0; row < vectors.size(); ++row) {
                vectors[row].resize(dim);
                for (uint64_t i = 0; i < dim; ++i) {
                    float value = random(generator);
                    if (trial == 0)
                        value = 0.0F;
                    if (trial == 1)
                        value = std::ldexp(value, -140);
                    if (trial == 2)
                        value = std::ldexp(value, 65);
                    vectors[row][i] = value;
                }
            }
            std::array<float, 4> results{};
            experimental_repair_batch4(vectors[0].data(),
                                       dim,
                                       vectors[1].data(),
                                       vectors[2].data(),
                                       vectors[3].data(),
                                       vectors[4].data(),
                                       results[0],
                                       results[1],
                                       results[2],
                                       results[3]);
            for (uint64_t lane = 0; lane < 4; ++lane) {
                const float expected =
                    avx512_fp32_distance(vectors[0].data(), vectors[lane + 1].data(), dim);
                if (bits(expected) != bits(results[lane]))
                    throw std::runtime_error("distance bits differ");
                ++compared;
            }
        }
    }
    std::cout << "PASS exact_float_bits " << compared << '\n';
}
