// Copyright 2024-present the vsag project
// SPDX-License-Identifier: Apache-2.0
// Private experiment: official batch kernel with the single-point Unroll=4 reduction order.
#include "lite/fp32_distance.h"
#include "simd/kernels/compute_batch4.h"
#include "simd/traits/simd_traits_avx512.h"
namespace vsag::lite::detail {
namespace {
void
batch4_fallback(const float* query,
                uint64_t dim,
                const float* c1,
                const float* c2,
                const float* c3,
                const float* c4,
                float& r1,
                float& r2,
                float& r3,
                float& r4) {
    r1 += avx512_fp32_distance(query, c1, dim);
    r2 += avx512_fp32_distance(query, c2, dim);
    r3 += avx512_fp32_distance(query, c3, dim);
    r4 += avx512_fp32_distance(query, c4, dim);
}
// The shared SIMD template requires these exact member names, including Width and zero.
// NOLINTBEGIN(readability-identifier-naming)
struct Unrolled4Traits {
    using Base = simd::SimdTraits<simd::Avx512Tag>;
    struct FloatVec {
        Base::FloatVec a;
        Base::FloatVec b;
        Base::FloatVec c;
        Base::FloatVec d;
    };
    static constexpr int Width = Base::Width * 4;
    static FloatVec
    zero() {
        return {Base::zero(), Base::zero(), Base::zero(), Base::zero()};
    }
    static FloatVec
    load(const float* value) {
        return {Base::load(value),
                Base::load(value + 16),
                Base::load(value + 32),
                Base::load(value + 48)};
    }
    static FloatVec
    sub(FloatVec left, FloatVec right) {
        return {Base::sub(left.a, right.a),
                Base::sub(left.b, right.b),
                Base::sub(left.c, right.c),
                Base::sub(left.d, right.d)};
    }
    static FloatVec
    fmadd(FloatVec left, FloatVec right, FloatVec sum) {
        return {Base::fmadd(left.a, right.a, sum.a),
                Base::fmadd(left.b, right.b, sum.b),
                Base::fmadd(left.c, right.c, sum.c),
                Base::fmadd(left.d, right.d, sum.d)};
    }
    static float
    reduce_add(FloatVec value) {
        auto sum = Base::add(value.a, value.b);
        sum = Base::add(sum, value.c);
        sum = Base::add(sum, value.d);
        return Base::reduce_add(sum);
    }
};
// NOLINTEND(readability-identifier-naming)
}  // namespace
__attribute__((visibility("hidden"))) void
experimental_repair_batch4(const float* query,
                           uint64_t dim,
                           const float* c1,
                           const float* c2,
                           const float* c3,
                           const float* c4,
                           float& r1,
                           float& r2,
                           float& r3,
                           float& r4) {
    if (dim < 64 || dim % 64 != 0) {
        r1 = avx512_fp32_distance(query, c1, dim);
        r2 = avx512_fp32_distance(query, c2, dim);
        r3 = avx512_fp32_distance(query, c3, dim);
        r4 = avx512_fp32_distance(query, c4, dim);
        return;
    }
    r1 = 0.0F;
    r2 = 0.0F;
    r3 = 0.0F;
    r4 = 0.0F;
    simd::ComputeBatch4Impl<Unrolled4Traits, simd::Batch4Kind::L2>(
        query, dim, c1, c2, c3, c4, r1, r2, r3, r4, batch4_fallback);
}
}  // namespace vsag::lite::detail
