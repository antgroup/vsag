"""Bring the numerical probe up to the same exception/bracing/loop rules."""
from pathlib import Path
import csv, difflib, hashlib, json, os, shlex, shutil, subprocess, tempfile, time
base=Path('/home/ubuntu/project')
repo=base/'vsag-pr2926-report-20261019';scope=base/'pr2926-community-scope-20261022'
pilot=base/'pr2926-repair-pilot-r2-20261023';build=scope/'reproduction/source-bound-build'
root=base/'pr2926-repair-exact-batch-20261025'
receipt=json.loads((base/'pr2926-repair-cost-validation-20261025/pushed.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==receipt['sha']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
assert 'bugprone-exception-escape' in (root/'numeric-tidy.log').read_text()
attempt=root/'numeric-attempt';attempt.mkdir(exist_ok=False)
for p in list(root.glob('*.log'))+[root/'commands.json',root/'numeric.cpp']:
    if p.is_file():shutil.copy2(p,attempt/p.name)
cpp=root/'graph_backend.cpp';kernel=root/'repair_batch_avx512.cpp';numeric=root/'numeric.cpp'
numeric.write_text('''// Copyright 2024-present the vsag project
// SPDX-License-Identifier: Apache-2.0
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <exception>
#include <iostream>
#include <random>
#include <stdexcept>
#include <vector>
#include "lite/fp32_distance.h"
namespace vsag::lite::detail {
void experimental_repair_batch4(const float*,uint64_t,const float*,const float*,const float*,const float*,float&,float&,float&,float&);
}
uint32_t bits(float value) {
    uint32_t result{};
    std::memcpy(&result,&value,sizeof(result));
    return result;
}
int run_numeric() {
    using namespace vsag::lite::detail;
    if(select_fp32_distance()!=avx512_fp32_distance) {
        throw std::runtime_error("AVX512 dispatcher required for this numerical pilot");
    }
    std::mt19937 generator(424242);
    std::uniform_real_distribution<float> random(-10.0F,10.0F);
    uint64_t compared=0;
    for(uint64_t dim:std::array<uint64_t,17>{1,15,16,17,63,64,65,127,128,129,767,768,769,959,960,961,1536}) {
        for(uint64_t trial=0;trial<64;++trial) {
            std::array<std::vector<float>,5> vectors;
            for(auto& values:vectors) {
                values.resize(dim);
                for(float& value:values) {
                    value=random(generator);
                    if(trial==0) { value=0.0F; }
                    if(trial==1) { value=std::ldexp(value,-140); }
                    if(trial==2) { value=std::ldexp(value,65); }
                }
            }
            std::array<float,4> results{};
            experimental_repair_batch4(vectors[0].data(),dim,vectors[1].data(),vectors[2].data(),vectors[3].data(),vectors[4].data(),results[0],results[1],results[2],results[3]);
            for(uint64_t lane=0;lane<4;++lane) {
                const float expected=avx512_fp32_distance(vectors[0].data(),vectors[lane+1].data(),dim);
                if(bits(expected)!=bits(results[lane])) { throw std::runtime_error("distance bits differ"); }
                ++compared;
            }
        }
    }
    std::cout<<"PASS exact_float_bits "<<compared<<'\\n';
    return 0;
}
int main() {
    try { return run_numeric(); }
    catch(const std::exception& error) { std::cerr<<error.what()<<'\\n';return 1; }
}
''')
original=(base/'repair-exact-batch-resume-20261025.py').read_text()
fragment=original[original.index("source=(pilot/'graph_backend.cpp').read_text()"):]
last=fragment.rfind("exec(compile(tail,__file__,'exec'))")
assert last>0
fragment=fragment[:last]+"tail=tail.replace('out=root/config;out.mkdir()', 'out=root/config;out.mkdir(exist_ok=True)')\n"+fragment[last:]
exec(compile(fragment,__file__,'exec'))
