"""Preserve failed prototype lint, provide real fallback, and rerun every gate."""
from pathlib import Path
import csv, difflib, hashlib, json, os, shlex, shutil, subprocess, tempfile, time

base=Path('/home/ubuntu/project')
repo=base/'vsag-pr2926-report-20261019'
scope=base/'pr2926-community-scope-20261022'
pilot=base/'pr2926-repair-pilot-r2-20261023'
build=scope/'reproduction/source-bound-build'
root=base/'pr2926-repair-exact-batch-20261025'
receipt=json.loads((base/'pr2926-repair-cost-validation-20261025/pushed.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==receipt['sha']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
assert not (root/'completed.json').exists()
assert 'Called function pointer is null' in (root/'kernel-tidy.log').read_text()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
first=root/'first-attempt';first.mkdir(exist_ok=False)
for p in list(root.glob('*.log'))+[root/'commands.json',root/'graph_backend.cpp',root/'repair_batch_avx512.cpp',root/'numeric.cpp',root/'candidate.diff']:
    if p.is_file():shutil.copy2(p,first/p.name)
shutil.copy2(base/'repair-exact-batch-20261025.py',first/'controller.py')
cpp=root/'graph_backend.cpp';kernel=root/'repair_batch_avx512.cpp';numeric=root/'numeric.cpp'
text=kernel.read_text()
anchor='struct Unrolled4Traits {';assert text.count(anchor)==1
text=text.replace(anchor,'''void
batch4_fallback(const float* query,uint64_t dim,const float* c1,const float* c2,const float* c3,const float* c4,
                float& r1,float& r2,float& r3,float& r4) {
    r1 += avx512_fp32_distance(query,c1,dim);
    r2 += avx512_fp32_distance(query,c2,dim);
    r3 += avx512_fp32_distance(query,c3,dim);
    r4 += avx512_fp32_distance(query,c4,dim);
}
// The shared SIMD template requires these exact member names, including Width and zero.
// NOLINTBEGIN(readability-identifier-naming)
'''+anchor)
anchor='};\n}  // namespace';assert text.count(anchor)==1
text=text.replace(anchor,'};\n// NOLINTEND(readability-identifier-naming)\n}  // namespace')
anchor='query, dim, c1, c2, c3, c4, r1, r2, r3, r4);';assert text.count(anchor)==1
text=text.replace(anchor,'query, dim, c1, c2, c3, c4, r1, r2, r3, r4, batch4_fallback);')
kernel.write_text(text)
source=(pilot/'graph_backend.cpp').read_text()
original=(base/'repair-exact-batch-20261025.py').read_text()
transform=original[original.index("original=(base/'crud-repair-cache-20261023.py').read_text()"):]
transform=transform[:transform.rindex("exec(compile(tail,__file__,'exec'))")]
exec(compile(transform,__file__,'exec'))
anchor='identity=dict(parent='
assert tail.count(anchor)==1
sanity='''# Exercise the actual wide-dimension mutation path under ASan/UBSan before timing.
san_entry=next(e for e in json.loads((scope/'sanitizer/compile_commands.json').read_text()) if e['file'].endswith('/graph_backend.cpp'))
san_args=shlex.split(san_entry['command']);san_args=san_args[:san_args.index('-o')]
san_args += [str(probe_path),'-L'+str(root/'san'),'-Wl,-rpath,'+str(root/'san'),'-lvsag-lite','-o',str(root/'san/mutation-probe')]
run('san-mutation-probe-compile',san_args)
sanity_rows=[]
for mode in ['update','replace','reinsert']:
    with tempfile.TemporaryDirectory(prefix='vsag-exact-batch-san-',dir='/dev/shm') as directory:
        hashes={}
        for side in ['r2','san']:
            folder=Path(directory)/side
            executable=root/'probe' if side=='r2' else root/'san/mutation-probe'
            extra={'LD_LIBRARY_PATH':str(pilot if side=='r2' else root/'san')}
            if side=='san': extra.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
            run('sanity-'+mode+'-'+side,['taskset','-c','0',str(executable),'/home/ubuntu/project/pr2926-three-dataset-resident-20261019/prepared/GIST/scale-10000',str(folder),mode,'1','16','fp32'],extra)
            hashes[side]=sha(folder/'final.snapshot')
        assert hashes['r2']==hashes['san']
        sanity_rows.append(dict(mode=mode,snapshots=hashes,rounds=1,cycles=16,dim=960))
(root/'san-mutation-checks.json').write_text(json.dumps(dict(status='PASS',rows=sanity_rows,not_timing=True),indent=2)+'\\n')
'''
tail=tail.replace(anchor,sanity+anchor)
exec(compile(tail,__file__,'exec'))
