"""Reuse validated owned build directories while preserving both earlier attempts."""
from pathlib import Path
import csv, difflib, hashlib, json, os, shlex, shutil, subprocess, tempfile, time
base=Path('/home/ubuntu/project')
repo=base/'vsag-pr2926-report-20261019';scope=base/'pr2926-community-scope-20261022'
pilot=base/'pr2926-repair-pilot-r2-20261023';build=scope/'reproduction/source-bound-build'
root=base/'pr2926-repair-exact-batch-20261025'
receipt=json.loads((base/'pr2926-repair-cost-validation-20261025/pushed.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==receipt['sha']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
assert 'FileExistsError' in (base/'repair-exact-batch-resume-20261025.log').read_text()
assert not (root/'completed.json').exists()
attempt=root/'resume-attempt';attempt.mkdir(exist_ok=False)
for p in list(root.glob('*.log'))+[root/'commands.json']:
    if p.is_file():shutil.copy2(p,attempt/p.name)
shutil.copy2(base/'repair-exact-batch-resume-20261025.log',attempt/'controller.log')
cpp=root/'graph_backend.cpp';kernel=root/'repair_batch_avx512.cpp';numeric=root/'numeric.cpp'
assert kernel.read_text().count('NOLINTBEGIN(readability-identifier-naming)')==1
assert kernel.read_text().count('r4, batch4_fallback);')==1
original=(base/'repair-exact-batch-resume-20261025.py').read_text()
fragment=original[original.index("source=(pilot/'graph_backend.cpp').read_text()"):]
last=fragment.rfind("exec(compile(tail,__file__,'exec'))")
assert last>0
fragment=fragment[:last]+"tail=tail.replace('out=root/config;out.mkdir()', 'out=root/config;out.mkdir(exist_ok=True)')\n"+fragment[last:]
exec(compile(fragment,__file__,'exec'))
