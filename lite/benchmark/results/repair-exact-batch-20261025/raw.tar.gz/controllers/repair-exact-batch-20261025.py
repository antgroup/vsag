"""Remote-only exact-order batch pilot, sequential after the current published cohort."""
from pathlib import Path
import csv, difflib, hashlib, json, os, shlex, subprocess, tempfile, time

base=Path('/home/ubuntu/project')
done=base/'pr2926-repair-cost-validation-20261025/pushed.json'
deadline=time.monotonic()+7200
while not done.exists():
    assert time.monotonic()<deadline
    time.sleep(5)
receipt=json.loads(done.read_text());assert receipt['status']=='PASS'
repo=base/'vsag-pr2926-report-20261019'
scope=base/'pr2926-community-scope-20261022'
pilot=base/'pr2926-repair-pilot-r2-20261023'
build=scope/'reproduction/source-bound-build'
root=base/'pr2926-repair-exact-batch-20261025';root.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==receipt['sha']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
source=(pilot/'graph_backend.cpp').read_text()
assert sha(pilot/'graph_backend.cpp')=='a4cc79be004315a9c1004d40dc0dd7e0a2ea76a413a0edafca3aec2069bd9c97'
kernel=root/'repair_batch_avx512.cpp'
kernel.write_text('''// Copyright 2024-present the vsag project
// SPDX-License-Identifier: Apache-2.0
// Private experiment: official batch kernel with the single-point Unroll=4 reduction order.
#include "lite/fp32_distance.h"
#include "simd/kernels/compute_batch4.h"
#include "simd/traits/simd_traits_avx512.h"
namespace vsag::lite::detail {
namespace {
struct Unrolled4Traits {
    using Base = simd::SimdTraits<simd::Avx512Tag>;
    struct FloatVec {
        Base::FloatVec a;
        Base::FloatVec b;
        Base::FloatVec c;
        Base::FloatVec d;
    };
    static constexpr int Width = Base::Width * 4;
    static FloatVec zero() { return {Base::zero(), Base::zero(), Base::zero(), Base::zero()}; }
    static FloatVec load(const float* value) {
        return {Base::load(value), Base::load(value + 16), Base::load(value + 32), Base::load(value + 48)};
    }
    static FloatVec sub(FloatVec left, FloatVec right) {
        return {Base::sub(left.a, right.a), Base::sub(left.b, right.b), Base::sub(left.c, right.c), Base::sub(left.d, right.d)};
    }
    static FloatVec fmadd(FloatVec left, FloatVec right, FloatVec sum) {
        return {Base::fmadd(left.a,right.a,sum.a), Base::fmadd(left.b,right.b,sum.b), Base::fmadd(left.c,right.c,sum.c), Base::fmadd(left.d,right.d,sum.d)};
    }
    static float reduce_add(FloatVec value) {
        auto sum=Base::add(value.a,value.b);
        sum=Base::add(sum,value.c);
        sum=Base::add(sum,value.d);
        return Base::reduce_add(sum);
    }
};
}
__attribute__((visibility("hidden"))) void
experimental_repair_batch4(const float* query, uint64_t dim,
                          const float* c1,const float* c2,const float* c3,const float* c4,
                          float& r1,float& r2,float& r3,float& r4) {
    if(dim<64 || dim%64!=0) {
        r1=avx512_fp32_distance(query,c1,dim);
        r2=avx512_fp32_distance(query,c2,dim);
        r3=avx512_fp32_distance(query,c3,dim);
        r4=avx512_fp32_distance(query,c4,dim);
        return;
    }
    r1=0.0F;r2=0.0F;r3=0.0F;r4=0.0F;
    simd::ComputeBatch4Impl<Unrolled4Traits,simd::Batch4Kind::L2>(query,dim,c1,c2,c3,c4,r1,r2,r3,r4);
}
}
''')
numeric=root/'numeric.cpp'
numeric.write_text('''// Copyright 2024-present the vsag project
// SPDX-License-Identifier: Apache-2.0
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <random>
#include <stdexcept>
#include <vector>
#include "lite/fp32_distance.h"
namespace vsag::lite::detail {
void experimental_repair_batch4(const float*,uint64_t,const float*,const float*,const float*,const float*,float&,float&,float&,float&);
}
uint32_t bits(float value) {
    uint32_t result{};
    std::memcpy(&result,&value,sizeof(result));
    return result;
}
int main() {
    using namespace vsag::lite::detail;
    if(select_fp32_distance()!=avx512_fp32_distance) throw std::runtime_error("AVX512 dispatcher required for this numerical pilot");
    std::mt19937 generator(424242);
    std::uniform_real_distribution<float> random(-10.0F,10.0F);
    uint64_t compared=0;
    for(uint64_t dim:std::array<uint64_t,17>{1,15,16,17,63,64,65,127,128,129,767,768,769,959,960,961,1536}) {
        for(uint64_t trial=0;trial<64;++trial) {
            std::array<std::vector<float>,5> vectors;
            for(uint64_t row=0;row<vectors.size();++row) {
                vectors[row].resize(dim);
                for(uint64_t i=0;i<dim;++i) {
                    float value=random(generator);
                    if(trial==0) value=0.0F;
                    if(trial==1) value=std::ldexp(value,-140);
                    if(trial==2) value=std::ldexp(value,65);
                    vectors[row][i]=value;
                }
            }
            std::array<float,4> results{};
            experimental_repair_batch4(vectors[0].data(),dim,vectors[1].data(),vectors[2].data(),vectors[3].data(),vectors[4].data(),results[0],results[1],results[2],results[3]);
            for(uint64_t lane=0;lane<4;++lane) {
                const float expected=avx512_fp32_distance(vectors[0].data(),vectors[lane+1].data(),dim);
                if(bits(expected)!=bits(results[lane])) throw std::runtime_error("distance bits differ");
                ++compared;
            }
        }
    }
    std::cout<<"PASS exact_float_bits "<<compared<<'\\n';
}
''')
declaration='''
#ifdef VSAG_LITE_HAS_X86_SIMD
__attribute__((visibility("hidden"))) void experimental_repair_batch4(
    const float*,uint64_t,const float*,const float*,const float*,const float*,float&,float&,float&,float&);
#endif
'''
anchor='namespace vsag::lite::detail {'
assert source.count(anchor)==1
modified=source.replace(anchor,anchor+declaration)
start=modified.index('    void\n    repair(');stop=modified.index('\n    template <typename T>',start)
body=modified[start:stop]
anchor='        auto targets = affected_nodes;'
assert body.count(anchor)==1
body=body.replace(anchor,'''        bool batch_first = false;
#ifdef VSAG_LITE_HAS_X86_SIMD
        batch_first = not fp16_ and build_source_ == nullptr and
                      distance_ == avx512_fp32_distance and dim_ >= 64 and dim_ % 64 == 0;
#endif
        std::vector<float> first_distances;
'''+anchor)
anchor='            std::vector<uint64_t> selected;'
assert body.count(anchor)==1
body=body.replace(anchor,'''#ifdef VSAG_LITE_HAS_X86_SIMD
            if(batch_first and not ranked.empty()) {
                first_distances.resize(ranked.size());
                uint64_t offset=1;
                const float* first=vectors_.data()+ranked.front().slot*dim_;
                for(;offset+4<=ranked.size();offset+=4) {
                    experimental_repair_batch4(first,dim_,
                        vectors_.data()+ranked[offset].slot*dim_,
                        vectors_.data()+ranked[offset+1].slot*dim_,
                        vectors_.data()+ranked[offset+2].slot*dim_,
                        vectors_.data()+ranked[offset+3].slot*dim_,
                        first_distances[offset],first_distances[offset+1],first_distances[offset+2],first_distances[offset+3]);
                }
                for(;offset<ranked.size();++offset) {
                    first_distances[offset]=distance(ranked.front().slot,ranked[offset].slot);
                }
            }
#endif
'''+anchor)
anchor='                    if (distance(neighbor, candidate.slot) < candidate.distance) {'
assert body.count(anchor)==1
body=body.replace(anchor,'''                    const float pair_distance = batch_first and neighbor == ranked.front().slot
                        ? first_distances[static_cast<uint64_t>(&candidate-ranked.data())]
                        : distance(neighbor,candidate.slot);
                    if (pair_distance < candidate.distance) {''')
cpp=root/'graph_backend.cpp';cpp.write_text(modified[:start]+body+modified[stop:])
original=(base/'crud-repair-cache-20261023.py').read_text()
tail=original[original.index('commands=[];env='):]
tail=tail.replace('pr2926-repair-cache-20261023','pr2926-repair-exact-batch-20261025')
tail=tail.replace('vsag-repair-cache-20261023-','vsag-repair-exact-batch-20261025-')
tail=tail.replace("probe='#include <sys/resource.h>\\n'+probe", "assert probe.count('#include <sys/resource.h>') == 1")
tail=tail.replace("parent='cec5b915fb1ab3d21fd7997749bad58c43ae497b'", "parent=receipt['sha']")
tail=tail.replace('cache_entries=256','cache_entries=0, candidate_kind="exact-order-first-neighbor-batch", kernel_source_sha256=sha(kernel)')
tail=tail.replace('One-repair cache only; direct-map replacement cannot change calculated values; no source/API/default changes',
    'Batch only first-selected occlusion distance; official batch template with Unroll4-compatible traits; FP32 AVX512 and dimension multiple64 only; all other paths unchanged')
anchor="run('format',['clang-format-15','--style=file:'+str(repo/'.clang-format'),'-i',str(cpp)])"
assert tail.count(anchor)==1
tail=tail.replace(anchor,anchor+'''
run('kernel-format',['clang-format-15','--style=file:'+str(repo/'.clang-format'),'-i',str(kernel),str(numeric)])
''')
anchor="    run(config+'-compile',args)"
assert tail.count(anchor)==1
tail=tail.replace(anchor,anchor+'''
    batch_entry=next(e for e in json.loads((path/'compile_commands.json').read_text()) if e['file'].endswith('/fp32_distance_avx512.cpp'))
    batch_args=shlex.split(batch_entry['command'])
    batch_args[batch_args.index('-o')+1]=str(out/'batch.o');batch_args[-1]=str(kernel)
    run(config+'-kernel-compile',batch_args)
    if config=='release':
        run('kernel-tidy',['clang-tidy-15',str(kernel),'--config-file='+str(repo/'.clang-tidy'),
            '--header-filter=.*/pr2926-repair-exact-batch-20261025/.*','--',*batch_args[1:batch_args.index('-o')]])
        run('numeric-tidy',['clang-tidy-15',str(numeric),'--config-file='+str(repo/'.clang-tidy'),
            '--header-filter=.*/pr2926-repair-exact-batch-20261025/.*','--',*batch_args[1:batch_args.index('-o')]])
''')
anchor="    run(config+'-link',args)";assert tail.count(anchor)==1
tail=tail.replace(anchor,"    args.append(str(out/'batch.o'))\n"+anchor)
anchor="    run(config+'-ctest',['ctest','--test-dir',str(suite),'--output-on-failure'],extra)"
assert tail.count(anchor)==1
tail=tail.replace(anchor,anchor+'''
    numeric_args=shlex.split(batch_entry['command'])
    numeric_args=numeric_args[:numeric_args.index('-o')]
    numeric_args += [str(numeric),str(out/'batch.o'),'-L'+str(out),'-Wl,-rpath,'+str(out),'-lvsag-lite','-o',str(out/'numeric')]
    run(config+'-numeric-compile',numeric_args)
    run(config+'-numeric',[str(out/'numeric')],extra)
    assert 'PASS exact_float_bits 4352' in (root/(config+'-numeric.log')).read_text()
''')
exec(compile(tail,__file__,'exec'))
