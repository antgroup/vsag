class ProcessHighWaterTests(unittest.TestCase):
    def test_optional_current_process_high_water_and_legacy_compatibility(self):
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            AcceptanceTests().fixture(folder)
            verify_run(folder,1,1,1)
            path = folder / 'states.csv'
            with path.open() as stream:
                states = list(csv.DictReader(stream))
            def write(values):
                with path.open('w',newline='') as stream:
                    writer = csv.DictWriter(stream,fieldnames=list(states[0])+['proc_hwm_kib'])
                    writer.writeheader()
                    for row,value in zip(states,values):
                        writer.writerow(dict(row,proc_hwm_kib=value))
            write([110,120])
            verify_run(folder,1,1,1)
            for invalid in [[0,120],[110,0],[120,110],[80,120]]:
                write(invalid)
                with self.assertRaises(AssertionError):
                    verify_run(folder,1,1,1)

    @unittest.skipUnless(os.environ.get('VSAG_MIXED_PROBE'), 'Compiled C++ probe required')
    def test_current_process_high_water_excludes_large_launcher_history(self):
        binary = str(Path(os.environ['VSAG_MIXED_PROBE']).resolve())
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            dataset = root / 'data'
            dataset.mkdir()
            for filename, count in [('base.fvecs',64),('queries.fvecs',5)]:
                with (dataset / filename).open('wb') as stream:
                    for identifier in range(count):
                        stream.write(struct.pack('<i17f',17,*[(identifier+1)*(d+1)*0.001 for d in range(17)]))
            snapshots = root / 'snapshots'
            snapshots.mkdir()
            output = root / 'output'
            launcher = '''import subprocess,sys
ballast=bytearray(96*1024*1024)
for offset in range(0,len(ballast),4096): ballast[offset]=1
subprocess.run(sys.argv[1:],check=True)
'''
            subprocess.run([sys.executable,'-c',launcher,binary,str(dataset),str(output),
                            'fp32','1','2',str(snapshots),'resident'],check=True,capture_output=True)
            verify_run(output,1,2,5)
            with (output / 'states.csv').open() as stream:
                states = list(csv.DictReader(stream))
            self.assertEqual(len(states),2)
            for state in states:
                self.assertGreaterEqual(int(state['peak_kib']),96*1024)
                self.assertGreater(int(state['proc_hwm_kib']),0)
                self.assertLess(int(state['proc_hwm_kib']),int(state['peak_kib'])/2)
                self.assertGreaterEqual(int(state['proc_hwm_kib'])+64,int(state['rss_kib']))


