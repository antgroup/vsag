"""Resume failed private probe lint; preserve first-attempt evidence and built libraries."""
from pathlib import Path
original = Path('/home/ubuntu/project/crud-repair-cache-20261023.py').read_text()
root = Path('/home/ubuntu/project/pr2926-repair-cache-20261023')
assert not (root/'completed.json').exists()
assert 'duplicate include' in (root/'probe-tidy.log').read_text()
for name in ['probe-tidy.log', 'commands.json']:
    (root/name).rename(root/('first-attempt-'+name))
setup = original[:original.index("root=Path('/home/ubuntu/project/pr2926-repair-cache")]
setup += "root=Path('/home/ubuntu/project/pr2926-repair-cache-20261023')\nbuild=scope/'reproduction/source-bound-build'\nsha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()\ncpp=root/'graph_backend.cpp'\n"
setup += original[original.index('commands=[];env='):original.index("run('format',")]
tail = original[original.index("probe=Path('/home/ubuntu/project/pr2926-repair-followup"):]
tail = tail.replace("probe='#include <sys/resource.h>\\n'+probe\n", "assert probe.count('#include <sys/resource.h>') == 1\n")
assert "probe='#include" not in tail
exec(compile(setup+tail, __file__, 'exec'))
