"""Remote-only, non-timed diagnostic overlays; published sources remain untouched."""
from pathlib import Path
import subprocess,shlex,json,os,time,hashlib
repo=Path('/home/ubuntu/project/vsag-pr2926-report-20261019')
scope=Path('/home/ubuntu/project/pr2926-community-scope-20261022')
pilot=Path('/home/ubuntu/project/pr2926-repair-pilot-r2-20261023')
root=Path('/home/ubuntu/project/pr2926-repair-counts-20261023')
root.mkdir(exist_ok=False)
build=scope/'reproduction/source-bound-build'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()=='cec5b915fb1ab3d21fd7997749bad58c43ae497b'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1'}
commands=[]
def run(tag,argv,extra=None):
    t=time.monotonic()
    with (root/(tag+'.log')).open('w') as stream:
        p=subprocess.run(argv,cwd=repo,env={**env,**(extra or {})},stdout=stream,stderr=subprocess.STDOUT)
    commands.append(dict(tag=tag,argv=list(map(str,argv)),exit=p.returncode,seconds=time.monotonic()-t))
    (root/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(tag,p.returncode,flush=True)
    assert p.returncode==0,tag
entry=next(e for e in json.loads((build/'compile_commands.json').read_text()) if e['file'].endswith('/graph_backend.cpp'))
link=subprocess.check_output(['ninja','-C',str(build),'-t','commands','vsag_lite'],text=True).splitlines()[-1]
assert link.startswith(': && ') and link.endswith(' && :')
diag='''#include <iostream>
#include <unordered_set>
namespace vsag_repair_diagnostic {
bool enabled = false;
uint64_t depth = 0;
uint64_t query_distance = 0;
uint64_t all_distance = 0;
uint64_t repair_distance = 0;
uint64_t repeated_distance = 0;
uint64_t repairs = 0;
uint64_t rows = 0;
uint64_t ensure_calls = 0;
uint64_t ensure_empty = 0;
uint64_t ensure_scans = 0;
std::unordered_set<uint64_t> seen;
struct RepairScope {
    RepairScope() { if (enabled) { ++repairs; ++depth; seen.clear(); } }
    ~RepairScope() { if (enabled) { --depth; } }
};
}
extern "C" void VSAGExperimentReset() {
    namespace d = vsag_repair_diagnostic;
    d::enabled = true;
}
extern "C" void VSAGExperimentDump() {
    namespace d = vsag_repair_diagnostic;
    d::enabled = false;
    std::cout << "COUNTS {\\"query_distance\\":" << d::query_distance
              << ",\\"all_distance\\":" << d::all_distance
              << ",\\"repair_distance\\":" << d::repair_distance
              << ",\\"repeated_distance\\":" << d::repeated_distance
              << ",\\"repairs\\":" << d::repairs << ",\\"rows\\":" << d::rows
              << ",\\"ensure_calls\\":" << d::ensure_calls
              << ",\\"ensure_empty\\":" << d::ensure_empty
              << ",\\"ensure_scans\\":" << d::ensure_scans << "}\\n";
}
'''
def one(s,a,b):
    assert s.count(a)==1,a
    return s.replace(a,b)
for side,path in [('baseline',repo/'src/lite/graph_backend.cpp'),('r2',pilot/'graph_backend.cpp')]:
    folder=root/side;folder.mkdir()
    source=path.read_text()
    source=one(source,'namespace vsag::lite::detail {',diag+'\nnamespace vsag::lite::detail {')
    source=one(source,'const std::vector<uint64_t>& additional_candidates) {','''const std::vector<uint64_t>& additional_candidates) {
        vsag_repair_diagnostic::RepairScope diagnostic_scope;''')
    source=one(source,'            remember_row(source, true, false);\n            const auto old_neighbors = '+('repaired;' if side=='baseline' else 'extras_[source];'),
        '            if (vsag_repair_diagnostic::enabled) { ++vsag_repair_diagnostic::rows; }\n            remember_row(source, true, false);\n            const auto old_neighbors = '+('repaired;' if side=='baseline' else 'extras_[source];'))
    source=one(source,'    ensure_incoming(uint64_t target) {','''    ensure_incoming(uint64_t target) {
        if (vsag_repair_diagnostic::enabled) { ++vsag_repair_diagnostic::ensure_calls; }''')
    source=one(source,'        uint64_t selected_source = Size();','''        if (vsag_repair_diagnostic::enabled) { ++vsag_repair_diagnostic::ensure_empty; }
        uint64_t selected_source = Size();''')
    source=one(source,'                const uint64_t displaced = extras_[source][edge];','''                if (vsag_repair_diagnostic::enabled) { ++vsag_repair_diagnostic::ensure_scans; }
                const uint64_t displaced = extras_[source][edge];''')
    source=one(source,'    distance(uint64_t left, uint64_t right) const {','''    distance(uint64_t left, uint64_t right) const {
        namespace d = vsag_repair_diagnostic;
        if (d::enabled) {
            ++d::all_distance;
            if (d::depth != 0) {
                ++d::repair_distance;
                const uint64_t key = (std::min(left, right) << 32) | std::max(left, right);
                if (not d::seen.insert(key).second) { ++d::repeated_distance; }
            }
        }''')
    source=one(source,'    distance(const float* query, const std::vector<uint16_t>& encoded_query, uint64_t slot) const {','''    distance(const float* query, const std::vector<uint16_t>& encoded_query, uint64_t slot) const {
        if (vsag_repair_diagnostic::enabled) { ++vsag_repair_diagnostic::query_distance; }''')
    cpp=folder/'graph_backend.cpp';cpp.write_text(source)
    run(side+'-format',['clang-format-15','--style=file:'+str(repo/'.clang-format'),'-i',str(cpp)])
    arguments=shlex.split(entry['command']);arguments[arguments.index('-o')+1]=str(folder/'candidate.o');arguments[-1]=str(cpp)
    run(side+'-compile',arguments)
    args=shlex.split(link[5:-5]);args[args.index('-o')+1]=str(folder/'libvsag-lite.so')
    for i,arg in enumerate(args):
        if arg.endswith('graph_backend.cpp.o'):args[i]=str(folder/'candidate.o')
        elif arg.endswith('.o'):args[i]=str(build/arg)
    run(side+'-link',args)
probe=Path('/home/ubuntu/project/pr2926-repair-followup-20261023/probe.cpp').read_text()
probe='#include <dlfcn.h>\n'+probe
probe=one(probe,'    const auto mutation_start = std::chrono::steady_clock::now();','''    using Diagnostic = void (*)();
    const auto reset = reinterpret_cast<Diagnostic>(dlsym(RTLD_DEFAULT, "VSAGExperimentReset"));
    const auto dump = reinterpret_cast<Diagnostic>(dlsym(RTLD_DEFAULT, "VSAGExperimentDump"));
    require(reset != nullptr and dump != nullptr, "diagnostic not bound");
    reset();
    const auto mutation_start = std::chrono::steady_clock::now();''')
stop=probe.index('    auto canonical = build(canonical_order);')
probe=probe[:stop]+'''    dump();
    std::ofstream stream(output / "final.snapshot", std::ios::binary);
    require(static_cast<bool>(maintained->Save(stream)), "save failed");
    stream.close();
    require(static_cast<bool>(stream), "close failed");
}
}  // namespace
int main(int argc, char** argv) {
    try { run(argc, argv); return 0; }
    catch (const std::exception& error) { std::cerr << error.what() << '\\n'; return 1; }
}
'''
cpp=root/'probe.cpp';cpp.write_text(probe)
run('probe-format',['clang-format-15','--style=file:'+str(repo/'.clang-format'),'-i',str(cpp)])
run('probe-compile',['c++','-std=c++17','-O3','-DNDEBUG','-Wall','-Wextra','-Wpedantic','-I'+str(repo/'include'),str(cpp),'-L'+str(build),'-Wl,-rpath,'+str(build),'-lvsag-lite','-ldl','-o',str(root/'probe')])
dataset='/home/ubuntu/project/pr2926-three-dataset-resident-20261019/prepared/GIST/scale-10000'
summary=[]
for mode in ['update','replace','reinsert']:
    for side in ['baseline','r2']:
        tag=mode+'-'+side
        run(tag,['taskset','-c','0',str(root/'probe'),dataset,str(root/tag),mode,'100','250','fp32'],{'LD_LIBRARY_PATH':str(root/side)})
        counts=json.loads(next(line[7:] for line in (root/(tag+'.log')).read_text().splitlines() if line.startswith('COUNTS ')))
        if side=='baseline':
            expected=json.loads((Path('/home/ubuntu/project/pr2926-crud-isolation-20261022')/mode/'GIST-fp32-0/audit.json').read_text())['snapshots']['round-100']['sha256']
        elif mode=='reinsert':
            expected=sha(pilot/'candidate/maintained.snapshot')
        else:
            items=json.loads((Path('/home/ubuntu/project/pr2926-repair-followup-20261023')/'rows.json').read_text())
            expected=next(r['candidate_sha256'] for r in items if r['dataset']=='GIST' and r['storage']=='fp32' and r['workload']==mode)
        actual=root/tag/'final.snapshot';assert sha(actual)==expected
        summary.append(dict(workload=mode,side=side,counts=counts,final_snapshot_sha256=sha(actual),bytes=actual.stat().st_size,exact=True))
        (root/'rows.json').write_text(json.dumps(summary,indent=2)+'\n')
        print(tag,json.dumps(counts),flush=True)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
(root/'completed.json').write_text(json.dumps(dict(status='PASS',cells=6,rows=summary,not_timing=True),indent=2)+'\n')
