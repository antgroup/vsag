"""Private experimental-library mixed CRUD run; never changes public/default sources."""
from pathlib import Path
import csv, hashlib, json, os, shutil, subprocess, sys, tempfile, time

repo = Path('/home/ubuntu/project/vsag-pr2926-report-20261019')
root = Path('/home/ubuntu/project/pr2926-repair-mixed-20261023')
cache = Path('/home/ubuntu/project/pr2926-repair-cache-20261023')
pilot = Path('/home/ubuntu/project/pr2926-repair-pilot-r2-20261023')
baseline = Path('/home/ubuntu/project/pr2926-community-scope-20261022/reproduction/source-bound-build')
old = Path('/home/ubuntu/project/pr2926-crud-isolation-20261022')
data = Path('/home/ubuntu/project/pr2926-three-dataset-resident-20261019/prepared/GIST/scale-10000')
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == 'cec5b915fb1ab3d21fd7997749bad58c43ae497b'
root.mkdir(exist_ok=False)
sys.path.insert(0, str(repo/'lite/benchmark'))
from run_mixed_cpu_acceptance import sha, verify_run, verify_checkpoints, percentile

def write(name, value):
    (root/name).write_text(json.dumps(value, indent=2)+'\n')

deadline = time.monotonic()+2400
while not (cache/'completed.json').exists():
    assert time.monotonic() < deadline, 'Cache matrix unfinished; do not overlap timings'
    time.sleep(5)
assert json.loads((cache/'completed.json').read_text())['status'] == 'PASS'
libs = dict(baseline=baseline/'libvsag-lite.so', r2=pilot/'libvsag-lite.so', cache=cache/'release/libvsag-lite.so')
assert sha(libs['baseline']) == '726c23082f0f0ac1a45ec8693e8a5d702ee78cadf089f23a57ae54b75f78b1ff'
assert sha(libs['r2']) == '967a0f5a4ab17019b04ab5e7cdc6e5b3e12e81df0655927eea77aac612b1387f'
assert sha(libs['cache']) == json.loads((cache/'identity.json').read_text())['cache_library_sha256']
assert sha(old/'mixed_cpu_acceptance.cpp') == sha(repo/'lite/benchmark/mixed_cpu_acceptance.cpp')
assert shutil.disk_usage('/dev/shm').free > 5*1024**3
shutil.copy2(old/'mixed_cpu_acceptance.cpp', root/'source.cpp')
write('identity.json', dict(schema='private-experimental-mixed-v1', parent='cec5b915fb1ab3d21fd7997749bad58c43ae497b',
    probe=str(old/'probe'), probe_sha256=sha(old/'probe'), source_sha256=sha(root/'source.cpp'),
    libraries={side:dict(path=str(p), sha256=sha(p), bytes=p.stat().st_size) for side,p in libs.items()},
    inputs={p.name:dict(bytes=p.stat().st_size, sha256=sha(p)) for p in [data/'base.fvecs',data/'queries.fvecs']},
    configuration=dict(dataset='GIST10k', dimension=960, query_rows=1000, distinct_query_rows=998, storage='fp32', degree=16,
        ef_construction=128, ef_search=512, k=10, cpu=0, threads=1, rounds=100, cycles=250, checkpoint_every=25,
        mutation_mode='all', resident=True, trials=1),
    boundary='One process per library, fixed baseline/r2/cache order; no repeated speed significance, no RaBitQ/FP16 generalization. Save/Load is explicit tmpfs snapshot consistency, not crash durability.'))
env = {**os.environ, 'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1'}
commands = []
rows = []
for side, lib in libs.items():
    extra = {**env, 'LD_LIBRARY_PATH':str(lib.parent)}
    binding = subprocess.check_output(['ldd',str(old/'probe')], env=extra, text=True)
    assert str(lib) in binding
    (root/(side+'-ldd.log')).write_text(binding)
    assert shutil.disk_usage('/dev/shm').free > 5*1024**3
    # Only this freshly created temporary directory is released. All evidence CSV stays on disk.
    with tempfile.TemporaryDirectory(prefix='vsag-repair-mixed-20261023-', dir='/dev/shm') as directory:
        output = root/side
        argv = ['taskset','-c','0',str(old/'probe'),str(data),str(output),'fp32','100','250',directory,'resident','25']
        write(side+'-command.json', dict(argv=argv, LD_LIBRARY_PATH=str(lib.parent)))
        started=time.monotonic()
        print('START',side,flush=True)
        with (root/(side+'.log')).open('w') as stream:
            result = subprocess.run(argv,env=extra,stdout=stream,stderr=subprocess.STDOUT)
        commands.append(dict(side=side,argv=argv,exit=result.returncode,process_wall_s=time.monotonic()-started))
        write('commands.json',commands)
        assert result.returncode == 0,side
        row = verify_run(output,100,250,1000)
        row['checkpoints'] = verify_checkpoints(output,100,250,1000,25)
        assert all(int(s['threads']) == 1 for s in row['states'])
        with (output/'samples.csv').open() as stream:
            samples=list(csv.DictReader(stream))
        position=0
        def consume(number, identifier, operation):
            global position
            item=samples[position]
            assert (int(item['round']),int(item['id']),item['operation']) == (number,identifier,operation)
            position+=1
        consume(0,-1,'build')
        query=0
        for number in range(1,101):
            for cycle in range(250):
                identifier=((number-1)*65537+cycle*8191)%10000
                for operation in ['update','remove','add']:
                    consume(number,identifier,operation)
                    consume(number,query%1000,'query')
                    query+=1
            consume(number,-1,'save')
            consume(number,-1,'load')
        assert position == len(samples)
        snapshots = {p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(Path(directory).iterdir())}
        assert set(snapshots) == {'round-'+str(n) for n in range(1,101)}
        assert all(v['bytes'] > 0 for v in snapshots.values())
        row.update(side=side,snapshots=snapshots)
        rows.append(row)
        write('rows.json',rows)
        assert json.loads((root/'rows.json').read_text()) == rows
    print('PASS',side,row['recall'],flush=True)
# Check all 100 graph snapshots, oracle IDs and ordered result IDs/distances, not timing columns.
r2 = next(r for r in rows if r['side']=='r2')
cached = next(r for r in rows if r['side']=='cache')
assert r2['snapshots'] == cached['snapshots']
assert (root/'r2/quality.csv').read_bytes() == (root/'cache/quality.csv').read_bytes()
for number in [0,25,50,75,100]:
    name=f'checkpoint-{number}-neighbors.csv'
    assert (root/'r2'/name).read_bytes() == (root/'cache'/name).read_bytes(), name
assert all(sha(p) == json.loads((root/'identity.json').read_text())['libraries'][s]['sha256'] for s,p in libs.items())
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
write('completed.json',dict(status='PASS',processes=3,mutation_calls=225000,interleaved_queries=225000,
    save_load_pairs=300,roundtrip_query_pairs=300000,checkpoints=15,cache_exact_r2=True,source_unchanged=True))
print('ALL PASS',flush=True)
