"""Read-only library scope; independent subprocess high-water accounting diagnostic."""
from pathlib import Path
import json,os,resource,subprocess,sys
root=Path('/home/ubuntu/project/pr2926-repair-mixed-20261023')
probe='''import json,resource
from pathlib import Path
status={line.split(':')[0]:int(line.split()[1]) for line in Path('/proc/self/status').read_text().splitlines() if line.startswith(('VmRSS:', 'VmHWM:'))}
print(json.dumps(dict(self_ru_maxrss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss, proc_status_kib=status)))
'''
results=[]
for phase in ['small_parent','large_parent']:
    if phase=='large_parent':
        ballast=bytearray(192*1024*1024)
        for position in range(0,len(ballast),4096):ballast[position]=1
    argv=['taskset','-c','0',sys.executable,'-c',probe]
    child=subprocess.run(argv,env=dict(os.environ),text=True,capture_output=True,check=True)
    results.append(dict(phase=phase,parent_ru_maxrss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,child=json.loads(child.stdout),argv=argv))
value=dict(scope='Separate launch-accounting diagnostic, not a rerun of index performance or proof of the exact formal-parent contribution.',rows=results,
    observation='Formal cache HWM is already 245916 KiB at round0 with RSS139928 KiB; do not attribute the whole peak difference to mutations or the 256-entry stack cache.')
(root/'launch-hwm-audit.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(value,indent=2))
