"""Exact-result local-to-repair cache candidate, built only in remote private output."""
from pathlib import Path
import subprocess,shlex,json,os,time,hashlib,difflib,sys,tempfile,csv
repo=Path('/home/ubuntu/project/vsag-pr2926-report-20261019')
scope=Path('/home/ubuntu/project/pr2926-community-scope-20261022')
pilot=Path('/home/ubuntu/project/pr2926-repair-pilot-r2-20261023')
root=Path('/home/ubuntu/project/pr2926-repair-cache-20261023');root.mkdir(exist_ok=False)
build=scope/'reproduction/source-bound-build'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(pilot/'graph_backend.cpp')=='a4cc79be004315a9c1004d40dc0dd7e0a2ea76a413a0edafca3aec2069bd9c97'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
source=(pilot/'graph_backend.cpp').read_text()
start=source.index('    void\n    repair(');stop=source.index('\n    template <typename T>',start)
body=source[start:stop]
anchor='        auto targets = affected_nodes;'
assert body.count(anchor)==1
body=body.replace(anchor,'''        // Ephemeral exact cache: vectors do not mutate during repair. No cross-operation state.
        std::array<uint64_t, 256> keys{};
        std::array<float, 256> values{};
        const auto cached_distance = [&](uint64_t left, uint64_t right) {
            if (Size() > UINT32_MAX) {
                return distance(left, right);
            }
            const uint64_t key = (std::min(left, right) << 32) | std::max(left, right);
            const uint64_t encoded = key + 1;
            uint64_t hash = key ^ (key >> 30);
            hash *= 0xbf58476d1ce4e5b9ULL;
            hash ^= hash >> 27;
            const uint64_t bucket = (hash * 0x94d049bb133111ebULL) >> 56;
            if (keys[bucket] != encoded) {
                values[bucket] = distance(left, right);
                keys[bucket] = encoded;
            }
            return values[bucket];
        };
'''+anchor)
assert body.count('distance(source, candidate)')==1 and body.count('distance(neighbor, candidate.slot)')==1
body=body.replace('distance(source, candidate)','cached_distance(source, candidate)').replace('distance(neighbor, candidate.slot)','cached_distance(neighbor, candidate.slot)')
cpp=root/'graph_backend.cpp';cpp.write_text(source[:start]+body+source[stop:])
commands=[];env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1'}
def run(tag,argv,extra=None,cwd=repo):
    t=time.monotonic()
    with (root/(tag+'.log')).open('w') as stream:
        p=subprocess.run(argv,cwd=cwd,env={**env,**(extra or {})},stdout=stream,stderr=subprocess.STDOUT)
    commands.append(dict(tag=tag,argv=list(map(str,argv)),exit=p.returncode,seconds=time.monotonic()-t))
    (root/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(tag,p.returncode,flush=True)
    assert p.returncode==0,tag
run('format',['clang-format-15','--style=file:'+str(repo/'.clang-format'),'-i',str(cpp)])
(root/'candidate.diff').write_text(''.join(difflib.unified_diff(source.splitlines(True),cpp.read_text().splitlines(True),fromfile='a/r2/graph_backend.cpp',tofile='b/cache/graph_backend.cpp')))
for config,path in [('release',build),('san',scope/'sanitizer')]:
    out=root/config;out.mkdir()
    entry=next(e for e in json.loads((path/'compile_commands.json').read_text()) if e['file'].endswith('/graph_backend.cpp'))
    args=shlex.split(entry['command']);args[args.index('-o')+1]=str(out/'candidate.o');args[-1]=str(cpp)
    run(config+'-compile',args)
    if config=='release':
        run('tidy',['clang-tidy-15',str(cpp),'--config-file='+str(repo/'.clang-tidy'),
            '--header-filter=.*/pr2926-repair-cache-20261023/.*','--',*shlex.split(entry['command'])[1:shlex.split(entry['command']).index('-o')]])
    link=subprocess.check_output(['ninja','-C',str(path),'-t','commands','vsag_lite'],text=True).splitlines()[-1]
    assert link.startswith(': && ') and link.endswith(' && :')
    args=shlex.split(link[5:-5]);args[args.index('-o')+1]=str(out/'libvsag-lite.so')
    for i,arg in enumerate(args):
        if arg.endswith('graph_backend.cpp.o'):args[i]=str(out/'candidate.o')
        elif arg.endswith('.o'):args[i]=str(path/arg)
    run(config+'-link',args)
    suite=scope/('release-on' if config=='release' else 'sanitizer')
    extra={'LD_LIBRARY_PATH':str(out)}
    if config=='san':extra.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    run(config+'-ldd',['ldd',str(suite/'lite_graph_tests')],extra)
    assert str(out/'libvsag-lite.so') in (root/(config+'-ldd.log')).read_text()
    run(config+'-ctest',['ctest','--test-dir',str(suite),'--output-on-failure'],extra)
probe=Path('/home/ubuntu/project/pr2926-repair-followup-20261023/probe.cpp').read_text()
probe='#include <sys/resource.h>\n'+probe
anchor='    const auto mutation_start = std::chrono::steady_clock::now();'
assert probe.count(anchor)==1
probe=probe.replace(anchor,'''    rusage before{};
    require(getrusage(RUSAGE_SELF, &before) == 0, "getrusage failed");
'''+anchor)
anchor='    auto canonical = build(canonical_order);';stop=probe.index(anchor)
probe=probe[:stop]+'''    rusage after{};
    require(getrusage(RUSAGE_SELF, &after) == 0, "getrusage failed");
    const auto seconds = [](const timeval& value) { return static_cast<double>(value.tv_sec) + static_cast<double>(value.tv_usec) / 1000000.0; };
    std::ofstream cpu(output / "cpu.csv");
    cpu << "user_s,system_s\\n" << std::setprecision(17)
        << seconds(after.ru_utime) - seconds(before.ru_utime) << ','
        << seconds(after.ru_stime) - seconds(before.ru_stime) << '\\n';
    cpu.close();
    require(static_cast<bool>(cpu), "CPU output failed");
    std::ofstream snapshot(output / "final.snapshot", std::ios::binary);
    require(static_cast<bool>(maintained->Save(snapshot)), "final save failed");
    snapshot.close();
    require(static_cast<bool>(snapshot), "snapshot write failed");
}
}  // namespace
int main(int argc, char** argv) {
    try { run(argc, argv); return 0; }
    catch (const std::exception& error) { std::cerr << error.what() << '\\n'; return 1; }
}
'''
probe_path=root/'probe.cpp';probe_path.write_text(probe)
run('probe-format',['clang-format-15','--style=file:'+str(repo/'.clang-format'),'-i',str(probe_path)])
run('probe-tidy',['clang-tidy-15',str(probe_path),'--config-file='+str(repo/'.clang-tidy'),
    '--header-filter=.*/pr2926-repair-cache-20261023/.*','--','-std=c++17','-I'+str(repo/'include')])
run('probe-compile',['c++','-std=c++17','-O3','-DNDEBUG','-Wall','-Wextra','-Wpedantic','-I'+str(repo/'include'),str(probe_path),'-L'+str(build),'-Wl,-rpath,'+str(build),'-lvsag-lite','-o',str(root/'probe')])
identity=dict(parent='cec5b915fb1ab3d21fd7997749bad58c43ae497b',r2_source_sha256=sha(pilot/'graph_backend.cpp'),
    r2_library_sha256=sha(pilot/'libvsag-lite.so'),cache_source_sha256=sha(cpp),cache_library_sha256=sha(root/'release/libvsag-lite.so'),
    probe_sha256=sha(probe_path),cache_entries=256,boundary='One-repair cache only; direct-map replacement cannot change calculated values; no source/API/default changes')
(root/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
# Do not overlap builds, diagnostic counters or cleanup with the timed matrix.
deadline=time.monotonic()+1200
while not Path('/home/ubuntu/project/pr2926-repair-counts-20261023/completed.json').exists():
    assert time.monotonic()<deadline,'Count diagnostic not complete'
    time.sleep(3)
rows=[]
expectedrows=json.loads(Path('/home/ubuntu/project/pr2926-repair-followup-20261023/rows.json').read_text())
plan=[(mode,trial) for mode in ['update','replace','reinsert'] for trial in range(3)]
(root/'plan.json').write_text(json.dumps(dict(cells=plan,storage='fp32',dataset='GIST10k',rounds=100,cycles=250,
    boundary='Loop wall/CPU includes formula and bookkeeping, not per-API tail latency; compare identical workload only'),indent=2)+'\n')
for number,(mode,trial) in enumerate(plan):
    records=[]
    with tempfile.TemporaryDirectory(prefix='vsag-repair-cache-20261023-',dir='/dev/shm') as directory:
        for side in (['r2','cache'] if number%2==0 else ['cache','r2']):
            folder=Path(directory)/side
            tag=f'{mode}-{trial}-{side}'
            run(tag,['taskset','-c','0',str(root/'probe'),'/home/ubuntu/project/pr2926-three-dataset-resident-20261019/prepared/GIST/scale-10000',str(folder),mode,'100','250','fp32'],
                {'LD_LIBRARY_PATH':str(pilot if side=='r2' else root/'release')})
            def read(name):
                with (folder/name).open() as stream:return next(csv.DictReader(stream))
            snapshots={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in folder.glob('*.snapshot')}
            expected=sha(pilot/'candidate/maintained.snapshot') if mode=='reinsert' else next(r['candidate_sha256'] for r in expectedrows if r['dataset']=='GIST' and r['storage']=='fp32' and r['workload']==mode)
            assert snapshots['final.snapshot']['sha256']==expected,'Changed r2 topology'
            timing=read('mutation-time.csv');cpu=read('cpu.csv')
            records.append(dict(workload=mode,trial=trial,side=side,loop_wall_ms=float(timing['wall_ms']),
                user_s=float(cpu['user_s']),system_s=float(cpu['system_s']),calls=int(timing['calls']),snapshots=snapshots,exact_r2=True))
            for filename in ['mutation-time.csv','cpu.csv']:
                (root/(tag+'-'+filename)).write_bytes((folder/filename).read_bytes())
        assert records[0]['snapshots']==records[1]['snapshots']
        rows.extend(records);(root/'rows.json').write_text(json.dumps(rows,indent=2)+'\n')
        assert json.loads((root/'rows.json').read_text())==rows
    print(mode,trial,[(r['side'],r['loop_wall_ms']) for r in records],flush=True)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
(root/'completed.json').write_text(json.dumps(dict(status='PASS',processes=18,calls=750000,rows=rows,
    source_unchanged=True,all_snapshots_equal_to_r2=True),indent=2)+'\n')
