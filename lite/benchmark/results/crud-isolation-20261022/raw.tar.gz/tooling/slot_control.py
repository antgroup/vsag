"""Run only after the complete timed matrix; public-API layout/maintenance control."""
from pathlib import Path
import subprocess,json,hashlib,os,csv,struct,time,sys
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
import numpy as np
repo=Path('/home/ubuntu/project/vsag-pr2926-report-20261019')
root=Path('/home/ubuntu/project/pr2926-crud-isolation-20261022')
scope=Path('/home/ubuntu/project/pr2926-community-scope-20261022')
assert len(sys.argv) in [1,5,6], 'usage: slot_control.py ISOLATION_ROOT REPO BUILD NEW_OUTPUT [GIST_DATA]'
if len(sys.argv)>1:
    root,repo,build,output=map(Path,sys.argv[1:5])
else:
    assert (root/'completed.json').exists() and not (root/'failed.txt').exists()
    build=scope/'reproduction/source-bound-build'
    output=root/'slot-controls'
identity=json.loads((root/'update/identity.json').read_text())
frozen_source=root/'mixed_cpu_acceptance.cpp'
if not frozen_source.exists():frozen_source=root/'update/source.cpp'
assert hashlib.sha256(frozen_source.read_bytes()).hexdigest()==identity['benchmark_source_sha256']
output.mkdir(exist_ok=False)
source=frozen_source.read_text()
prefix=source[:source.index('\nrusage\nusage()')].replace('using Clock = std::chrono::steady_clock;\n','')
helpers=source[source.index('std::vector<int64_t>\ntruth('):source.index('// Isolate fresh-build')]
program=prefix+helpers+'''
void
run(int argc, char** argv) {
    require(argc == 6, "usage: slot-control DATASET OUTPUT MODE ROUNDS CYCLES");
    const std::string mode(argv[3]);
    require(mode == "replace" or mode == "reinsert", "invalid mode");
    const uint64_t rounds = std::stoull(argv[4]);
    const uint64_t cycles = std::stoull(argv[5]);
    require(rounds > 0 and cycles > 0 and rounds <= 1000000 and cycles <= 1000000 and
                rounds * cycles <= 1000000, "invalid schedule");
    const std::filesystem::path output(argv[2]);
    require(not std::filesystem::exists(output), "output already exists");
    auto base = read_rows(std::string(argv[1]) + "/base.fvecs");
    const auto original = base;
    const auto queries = read_rows(std::string(argv[1]) + "/queries.fvecs");
    const uint64_t count = base.size();
    const uint64_t dim = base.front().size();
    require(count > 10 and queries.front().size() == dim, "invalid data");
    std::filesystem::create_directory(output);
    std::vector<uint64_t> canonical_order(count);
    std::vector<uint64_t> order(count);
    std::vector<uint64_t> slots(count);
    for (uint64_t id = 0; id < count; ++id) {
        canonical_order[id] = order[id] = slots[id] = id;
    }
    const auto build = [&](const std::vector<uint64_t>& sequence) {
        auto created = vsag::lite::Index::Create(dim);
        require(static_cast<bool>(created), "create failed");
        auto index = std::move(*created);
        for (const uint64_t id : sequence) {
            require(static_cast<bool>(index->Add(static_cast<int64_t>(id), base[id].data(), dim)),
                    "build add failed");
        }
        require(static_cast<bool>(index->BuildGraph(vsag::lite::VectorStorage::FP32, 16, 128)),
                "build graph failed");
        return index;
    };
    auto maintained = build(canonical_order);
    for (uint64_t round = 1; round <= rounds; ++round) {
        for (uint64_t cycle = 0; cycle < cycles; ++cycle) {
            const uint64_t id = ((round - 1) * 65537ULL + cycle * 8191ULL) % count;
            const uint64_t donor = (id + round * 97 + cycle + 1) % count;
            auto replacement = base[id];
            if (mode == "replace") {
                for (uint64_t d = 0; d < dim; ++d) {
                    replacement[d] = 0.875F * base[id][d] + 0.125F * original[donor][d];
                }
                require(replacement != base[id], "replacement unchanged");
            }
            require(maintained->Remove(static_cast<int64_t>(id)), "remove failed");
            const uint64_t position = slots[id];
            const uint64_t moved = order.back();
            order[position] = moved;
            slots[moved] = position;
            order.pop_back();
            require(static_cast<bool>(maintained->Add(static_cast<int64_t>(id), replacement.data(), dim)),
                    "readd failed");
            base[id] = replacement;
            slots[id] = order.size();
            order.push_back(id);
        }
    }
    auto canonical = build(canonical_order);
    auto same_order = build(order);
    const vsag::lite::Index* views[] = {maintained.get(), canonical.get(), same_order.get()};
    const std::string names[] = {"maintained", "canonical", "same_order"};
    for (uint64_t side = 0; side < 3; ++side) {
        std::ofstream stream(output / (names[side] + ".snapshot"), std::ios::binary);
        require(static_cast<bool>(stream) and static_cast<bool>(views[side]->Save(stream)),
                "save failed");
        stream.close();
        require(static_cast<bool>(stream), "close failed");
    }
    std::ofstream mapping(output / "slots.csv");
    mapping << "slot,id\\n";
    for (uint64_t slot = 0; slot < count; ++slot) {
        mapping << slot << ',' << order[slot] << '\\n';
    }
    std::ofstream rows(output / "neighbors.csv");
    rows << "query,rank,ef,truth_id,maintained_id,maintained_distance,canonical_id,canonical_distance,"
            "same_order_id,same_order_distance\\n" << std::setprecision(17);
    const std::vector<bool> live(count, true);
    for (uint64_t q = 0; q < queries.size(); ++q) {
        const auto expected = truth(base, queries[q], 10);
        for (const uint64_t ef : {uint64_t{512}, count}) {
            std::vector<vsag::lite::Neighbor> found[3];
            for (uint64_t side = 0; side < 3; ++side) {
                auto result = views[side]->SearchWithOptions(queries[q].data(), dim, 10, {ef});
                require(static_cast<bool>(result), "query failed");
                found[side] = std::move(*result);
                validate(found[side], live, 10);
            }
            for (uint64_t rank = 0; rank < 10; ++rank) {
                rows << q << ',' << rank << ',' << ef << ',' << expected[rank];
                for (const auto& values : found) {
                    rows << ',' << values[rank].id << ',' << values[rank].distance;
                }
                rows << '\\n';
            }
        }
    }
    mapping.close();
    rows.close();
    require(static_cast<bool>(mapping) and static_cast<bool>(rows), "output failed");
    std::cout << "PASS " << mode << " cycles=" << rounds * cycles << '\\n';
}
}  // namespace

int
main(int argc, char** argv) {
    try {
        run(argc, argv);
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\\n';
        return 1;
    }
}
'''
cpp=output/'slot-control.cpp';cpp.write_text(program)
subprocess.run(['clang-format-15','--style=file:'+str(repo/'.clang-format'),'-i',str(cpp)],check=True)
env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1'}
commands=[]
def run(tag,argv):
    start=time.monotonic()
    with (output/(tag+'.log')).open('w') as stream:
        p=subprocess.run(argv,cwd=repo,env=env,stdout=stream,stderr=subprocess.STDOUT)
    commands.append(dict(tag=tag,argv=list(map(str,argv)),exit=p.returncode,seconds=time.monotonic()-start))
    (output/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    print(tag,p.returncode,flush=True)
    assert p.returncode==0,tag
run('compile',['c++','-std=c++17','-O3','-DNDEBUG','-Wall','-Wextra','-Wpedantic','-I'+str(repo/'include'),str(cpp),'-L'+str(build),'-Wl,-rpath,'+str(build),'-lvsag-lite','-o',str(output/'probe')])
run('tidy',['clang-tidy-15',str(cpp),'--config-file='+str(repo/'.clang-tidy'),'--header-filter=.*/slot-controls/.*','--','-std=c++17','-I'+str(repo/'include')])
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
identity=json.loads((root/'update/identity.json').read_text())
assert sha(build/'libvsag-lite.so')==identity['library_sha256']
dataset=Path(identity['inputs']['GIST']['base.fvecs']['path']).parent
if len(sys.argv)==6:dataset=Path(sys.argv[5])
for name,entry in identity['inputs']['GIST'].items():assert sha(dataset/name)==entry['sha256'],name
original_rows=np.fromfile(dataset/'base.fvecs',dtype=np.dtype([('dim','<i4'),('vec','<f4',(960,))]))
assert len(original_rows)==10000 and (original_rows['dim']==960).all()
original=original_rows['vec'].copy()
def read(path):
    with path.open() as stream:return list(csv.DictReader(stream))
audits=[]
for mode in ['replace','reinsert']:
    folder=output/mode
    run(mode,['taskset','-c','0',str(output/'probe'),str(dataset),str(folder),mode,'100','250'])
    formal=root/mode/'GIST-fp32-0'
    measured=json.loads((formal/'audit.json').read_text())
    receipt=measured['snapshots']['round-100']
    actual=folder/'maintained.snapshot'
    assert actual.stat().st_size==receipt['bytes'] and sha(actual)==receipt['sha256'], 'Replay differs from timed index'
    mapping=[int(r['id']) for r in read(folder/'slots.csv')]
    assert len(mapping)==10000 and set(mapping)==set(range(10000))
    expected_vectors=original.copy()
    if mode=='replace':
        for number in range(1,101):
            for cycle in range(250):
                identifier=((number-1)*65537+cycle*8191)%10000
                donor=(identifier+number*97+cycle+1)%10000
                expected_vectors[identifier]=np.float32(.875)*expected_vectors[identifier]+np.float32(.125)*original[donor]
    vector_hashes={}
    for name,expected_order in [('maintained',mapping),('same_order',mapping),('canonical',list(range(10000)))]:
        with (folder/(name+'.snapshot')).open('rb') as stream:
            header=struct.unpack('<8s7Q',stream.read(64))
            assert header[0]==b'VSAGLT01' and header[1:4]==(2,960,10000) and header[5:]==(2,16,128),header
            ids=struct.unpack('<10000Q',stream.read(80000))
            assert list(ids)==expected_order,(mode,name,'wrong slot order')
            vector_bytes=stream.read(10000*960*4)
            assert vector_bytes==expected_vectors[np.array(expected_order)].tobytes(), (mode,name,'stored vector payload differs from independent FP32 replay')
            vector_hashes[name]=hashlib.sha256(vector_bytes).hexdigest()
    allrows=read(folder/'neighbors.csv')
    assert len(allrows)==20000
    expectedformal=read(formal/'checkpoint-100-neighbors.csv')
    expectedfull=read(formal/'ceiling.csv')
    summary={}
    for ef,reference in [(512,expectedformal),(10000,expectedfull)]:
        selected=[r for r in allrows if int(r['ef'])==ef]
        assert len(selected)==10000
        for index,(actual_row,expected_row) in enumerate(zip(selected,reference)):
            assert (int(actual_row['query']),int(actual_row['rank']))==divmod(index,10)
            assert actual_row['truth_id']==expected_row['truth_id']
            for side,oldside in [('maintained','maintained'),('canonical','fresh')]:
                assert actual_row[side+'_id']==expected_row[oldside+'_id']
                assert actual_row[side+'_distance']==expected_row[oldside+'_distance']
        summary[str(ef)]={}
        for side in ['maintained','canonical','same_order']:
            hits=0
            for q in range(1000):
                group=selected[q*10:(q+1)*10]
                truth_ids={int(r['truth_id']) for r in group}
                values=[(float(r[side+'_distance']),int(r[side+'_id'])) for r in group]
                assert values==sorted(values) and len({i for _,i in values})==10
                hits+=len(truth_ids & {i for _,i in values})
            summary[str(ef)][side]=hits/10000
        assert all(v==1 for v in summary['10000'].values()) if ef==10000 else True
    snapshots={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in folder.glob('*.snapshot')}
    audits.append(dict(mode=mode,storage='fp32',replay_snapshot_matches_timed=True,actual_snapshot_ids_match_simulated_order=True,
        all_stored_fp32_vectors_match_independent_replay=True,vector_payload_sha256=vector_hashes,
        quality=summary,snapshots=snapshots,query_rows=1000,neighbors_rows=20000,
        interpretation='Fresh build uses the same final slot order but regenerates adjacency; it does not freeze the measured implicit ring and seeds independently of the explicit graph'))
    (folder/'audit.json').write_text(json.dumps(audits[-1],indent=2)+'\n')
assert sha(build/'libvsag-lite.so')==identity['library_sha256']
if len(sys.argv)==1:
    sanitizer=scope/'sanitizer'
    run('san-compile',['c++','-std=c++17','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer',
        '-I'+str(repo/'include'),str(cpp),'-L'+str(sanitizer),'-Wl,-rpath,'+str(sanitizer),'-lvsag-lite','-o',str(output/'san-probe')])
    env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    smoke=json.loads((scope/'reproduction/mixed/identity.json').read_text())
    small_data=Path(smoke['inputs']['GIST256']['base.fvecs']['path']).parent
    run('san-fixture',['taskset','-c','0',str(output/'san-probe'),str(small_data),str(output/'san-fixture'),'reinsert','3','7'])
(output/'audit.json').write_text(json.dumps(dict(status='PASS',cells=audits,source_sha256=sha(cpp),library_sha256=identity['library_sha256'],
    sanitizer_fixture_passed=len(sys.argv)==1,
    boundary='Untimed FP32 replay/layout control after the timed matrix; not new performance or new algorithm evidence'),indent=2)+'\n')
print(json.dumps(audits,indent=2),flush=True)
