"""Offline analysis only; run after all measured processes exit.

Usage: python analyze.py ISOLATION_ROOT E13_RAW_ROOT OUTPUT_DIRECTORY
Requires NumPy and the accompanying frozen runner/verifier modules.
"""
import os
os.environ.update(OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1')
from pathlib import Path
import csv
import json
import sys
import hashlib
import numpy as np

rawroot, oldroot, out = map(Path, sys.argv[1:4])
dataset_override = Path(sys.argv[4]) if len(sys.argv) == 5 else None
sys.path.insert(0,str(rawroot))
from verify_mixed_cpu_acceptance import verify
out.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def read_csv(path):
    with path.open() as stream:
        return list(csv.DictReader(stream))
def read_fvecs(path):
    with path.open('rb') as stream:
        dim = int.from_bytes(stream.read(4), 'little', signed=True)
    data = np.fromfile(path, dtype=np.dtype([('dim', '<i4'), ('vec', '<f4', (dim,))]))
    assert (data['dim'] == dim).all() and np.isfinite(data['vec']).all()
    return data['vec'].copy()
identities={mode:json.loads((rawroot/mode/'identity.json').read_text())
            for mode in ['update','replace','reinsert']}
oldidentity=json.loads((oldroot/'identity.json').read_text())
audits={mode:verify(rawroot/mode) for mode in identities}
audits['E13']=verify(oldroot)
library='726c23082f0f0ac1a45ec8693e8a5d702ee78cadf089f23a57ae54b75f78b1ff'
for mode,identity in identities.items():
    config=identity['configuration']
    assert identity['library_sha256']==oldidentity['library_sha256']==library
    assert config['mutation_mode']==mode and config['checkpoint_every']==25 and config['resident']
    assert config['rounds']==100 and config['cycles']==250 and config['trials']==1
    assert all(config[k]==v for k,v in dict(degree=16,construction_ef=128,query_ef=512,k=10,cpu=0).items())
    assert identity['inputs']==oldidentity['inputs']
    assert identity['benchmark_source_sha256']==identities['update']['benchmark_source_sha256']
    assert identity['binary_sha256']==identities['update']['binary_sha256']
inputs=identities['update']['inputs']['GIST']
paths={name: dataset_override/name if dataset_override else Path(entry['path']) for name,entry in inputs.items()}
for name,entry in inputs.items():
    assert sha(paths[name])==entry['sha256']
original=read_fvecs(paths['base.fvecs'])
queries=read_fvecs(paths['queries.fvecs'])
assert original.shape==(10000,960) and queries.shape==(1000,960)
rows={mode:json.loads((rawroot/mode/'rows.json').read_text()) for mode in identities}
oldrows=json.loads((oldroot/'rows.json').read_text())
truths={};neighbors={};samples={};curve=[];ceilings={}
for mode in identities:
    for row in rows[mode]:
        storage=row['storage'];folder=rawroot/mode/f'GIST-{storage}-0'
        ceilings[mode,storage]=read_csv(folder/'ceiling.csv')
        assert row['recall']['0']==next(r for r in oldrows if r['storage']==storage)['recall']['0']
        for number in [0,25,50,75,100]:
            key=mode,storage,number
            neighbor=read_csv(folder/f'checkpoint-{number}-neighbors.csv')
            truths[key]=np.array([int(r['truth_id']) for r in neighbor]).reshape(1000,10)
            neighbors[key]=neighbor
            timing=read_csv(folder/f'checkpoint-{number}-queries.csv')
            samples[key]={side:np.array([int(r[side+'_hits'])/10 for r in timing]) for side in ['maintained','fresh']}
            if number==0:
                assert all(r['maintained_id']==r['fresh_id'] and r['maintained_distance']==r['fresh_distance'] for r in neighbor)
            cell=row['checkpoints'][str(number)];state=row['states'][number]
            curve.append(dict(workload=mode,storage=storage,round=number,cycles=number*250,
                mutation_calls=cell['mutation_calls'],maintained_recall=cell['maintained_recall'],
                fresh_recall=cell['fresh_recall'],gap_pp=(cell['fresh_recall']-cell['maintained_recall'])*100,
                maintained_p50_us=cell['maintained_p50_us'],fresh_p50_us=cell['fresh_p50_us'],
                rss_before_persistence_kib=int(state['rss_before_persistence_kib']),
                peak_kib=int(state['peak_kib']),snapshot_bytes=int(state['snapshot_bytes'])))
for number in [0,25,50,75,100]:
    for mode in identities:
        assert all(np.array_equal(truths[mode,'fp32',number],truths[mode,storage,number]) for storage in ['fp16','rabitq8'])
    assert np.array_equal(truths['update','fp32',number],truths['replace','fp32',number])
    assert np.array_equal(truths['reinsert','fp32',number],truths['reinsert','fp32',0])
    # FP32/FP16 fresh rebuild is deterministic on identical data, across update/replace histories.
    # RaBitQ fresh build also retrains, but identical rebuild inputs must give identical output.
    for storage in ['fp32','fp16','rabitq8']:
        a=neighbors['update',storage,number];b=neighbors['replace',storage,number]
        assert [(r['fresh_id'],r['fresh_distance']) for r in a]==[(r['fresh_id'],r['fresh_distance']) for r in b]
        static=neighbors['reinsert',storage,number];initial=neighbors['reinsert',storage,0]
        assert [(r['fresh_id'],r['fresh_distance']) for r in static]==[(r['fresh_id'],r['fresh_distance']) for r in initial]
        if number in [0,50,100]:
            old=read_csv(oldroot/f'GIST-{storage}-0'/f'checkpoint-{number}-neighbors.csv')
            assert [r['truth_id'] for r in old]==[r['truth_id'] for r in a]
            assert [(r['fresh_id'],r['fresh_distance']) for r in old]==[(r['fresh_id'],r['fresh_distance']) for r in a]
# Independent formula replay with separate float32 multiply and add, then FP64 distances.
selected=[0,1,2,5,11,29,97,313,617,999]
checked=0;base=original.copy();updated=set();geometry=[]
for number in range(101):
    if number:
        for cycle in range(250):
            identifier=((number-1)*65537+cycle*8191)%len(base)
            donor=(identifier+number*97+cycle+1)%len(base)
            base[identifier]=np.float32(.875)*base[identifier]+np.float32(.125)*original[donor]
            updated.add(identifier)
    if number not in [0,25,50,75,100]:
        continue
    geometry.append(dict(round=number,unique_changed_ids=len(updated),fp32_sha256=hashlib.sha256(base.tobytes()).hexdigest()))
    for data,mode in [(base,'update'),(original,'reinsert')]:
        for q in selected:
            delta=data.astype(np.float64)-queries[q].astype(np.float64)
            distances=np.einsum('ij,ij->i',delta,delta,optimize=False)
            expected=np.lexsort((np.arange(len(data)),distances))[:10]
            assert np.array_equal(expected,truths[mode,'fp32',number][q]),(mode,number,q)
            checked+=1
# Conditional query-cluster bootstrap. Same graph per cell: not independent build replicates.
groups={}
for q,query in enumerate(queries):groups.setdefault(query.tobytes(),[]).append(q)
assert len(groups)==998
clusters=list(groups.values());weights=np.array([len(g) for g in clusters])
rng=np.random.default_rng(20261022)
indices=rng.integers(0,len(clusters),size=(5000,len(clusters)))
def paired(a,b):
    delta=(a-b)*100
    aggregate=np.array([delta[g].sum() for g in clusters])
    distribution=aggregate[indices].sum(axis=1)/weights[indices].sum(axis=1)
    low,high=np.quantile(distribution,[.025,.975])
    return dict(delta_pp=float(delta.mean()),conditional_query_cluster_bootstrap_95_pp=[float(low),float(high)],
        query_win=int((delta>0).sum()),query_loss=int((delta<0).sum()),query_tie=int((delta==0).sum()))
pairs=[]
for mode in identities:
    for storage in ['fp32','fp16','rabitq8']:
        for number in [0,25,50,75,100]:
            cell=samples[mode,storage,number]
            pairs.append(dict(comparison='fresh-minus-maintained',workload=mode,storage=storage,round=number,
                              **paired(cell['fresh'],cell['maintained'])))
for storage in ['fp32','fp16','rabitq8']:
    for number in [0,25,50,75,100]:
        pairs.append(dict(comparison='update-minus-replace',storage=storage,round=number,
            **paired(samples['update',storage,number]['maintained'],samples['replace',storage,number]['maintained'])))
        pairs.append(dict(comparison='reinsert-minus-initial',storage=storage,round=number,
            **paired(samples['reinsert',storage,number]['maintained'],samples['reinsert',storage,0]['maintained'])))
def save(name,value):
    (out/name).write_text(json.dumps(value,indent=2)+'\n')
ceiling_comparisons=[]
for storage in ['fp32','fp16','rabitq8']:
    a,b=ceilings['update',storage],ceilings['replace',storage]
    keys=['truth_id','maintained_id','maintained_distance']
    mismatches=[q for q in range(1000) if [[r[k] for k in keys] for r in a[q*10:(q+1)*10]] !=
                [[r[k] for k in keys] for r in b[q*10:(q+1)*10]]]
    ceiling_comparisons.append(dict(storage=storage,comparison='update-versus-replace-final-ef=N',
        ordered_id_distance_equal=not mismatches,mismatched_queries=mismatches))
save('ceiling-comparisons.json',ceiling_comparisons)
save('curve.json',curve);save('paired.json',pairs);save('geometry.json',geometry)
with (out/'curve.csv').open('w',newline='') as stream:
    writer=csv.DictWriter(stream,fieldnames=list(curve[0]));writer.writeheader();writer.writerows(curve)
audit=dict(status='PASS',cohorts=audits,processes=9,total_mutations=sum(audits[m]['mutation_calls'] for m in identities),
    total_interleaved_queries=sum(audits[m]['interleaved_queries'] for m in identities),checkpoint_states=45,
    independent_numpy_FP64_query_states=checked,independent_scope='10 prespecified queries x5 checkpoints x2 geometries, each over all10000 vectors',
    all_45000_truth_query_states_consistent_across_storage_and_workload_controls=True,
    same_data_fresh_rebuild_results_exact=True,reinsert_fresh_results_and_truth_constant=True,
    query_rows=1000,distinct_query_content_clusters=998,bootstrap_seed=20261022,bootstrap_draws=5000,
    bootstrap_scope='Conditional on one graph per cell; resamples query-content clusters, not builds or endurance repeats',
    no_production_change=True,no_per_operation_durability_claim=True)
audit['update_replace_final_full_budget_ordered_results_equal']=all(r['ordered_id_distance_equal'] for r in ceiling_comparisons)
save('independent-audit.json',audit)
print(json.dumps(audit,indent=2))
for mode in identities:
    for row in rows[mode]:print(mode,row['storage'],row['recall'],row['checkpoints']['100'],row['ceiling'])
