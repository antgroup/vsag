"""Isolated hypothesis test, never edits the repository or a published library."""
from pathlib import Path
import csv,difflib,hashlib,json,os,shlex,subprocess,time,struct
repo=Path('/home/ubuntu/project/vsag-pr2926-report-20261019')
root=Path('/home/ubuntu/project/pr2926-repair-pilot-r2-20261023')
scope=Path('/home/ubuntu/project/pr2926-community-scope-20261022')
formal=Path('/home/ubuntu/project/pr2926-crud-isolation-20261022')
build=scope/'reproduction/source-bound-build'
root.mkdir(exist_ok=False)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()=='f60c0fb5871bdacaa150fdf315eba19a2796ad64'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
baseline_sha=sha(build/'libvsag-lite.so')
assert baseline_sha=='726c23082f0f0ac1a45ec8693e8a5d702ee78cadf089f23a57ae54b75f78b1ff'
original=(repo/'src/lite/graph_backend.cpp').read_text()
begin=original.index('    void\n    repair(')
end=original.index('\n    template <typename T>',begin)
replacement='''    void
    repair(std::vector<uint64_t> affected_nodes,
           const std::vector<uint64_t>& additional_candidates) {
        std::sort(affected_nodes.begin(), affected_nodes.end());
        affected_nodes.erase(std::unique(affected_nodes.begin(), affected_nodes.end()),
                             affected_nodes.end());
        auto targets = affected_nodes;
        for (const uint64_t source : affected_nodes) {
            if (source >= Size()) {
                continue;
            }
            remember_row(source, true, false);
            const auto old_neighbors = extras_[source];
            targets.insert(targets.end(), old_neighbors.begin(), old_neighbors.end());
            auto candidates = old_neighbors;
            candidates.insert(candidates.end(), additional_candidates.begin(),
                              additional_candidates.end());
            std::sort(candidates.begin(), candidates.end());
            candidates.erase(std::unique(candidates.begin(), candidates.end()), candidates.end());
            std::vector<Candidate> ranked;
            ranked.reserve(candidates.size());
            for (const uint64_t candidate : candidates) {
                if (candidate < Size() and candidate != source) {
                    ranked.push_back({candidate, distance(source, candidate)});
                }
            }
            std::sort(ranked.begin(), ranked.end(), Closer{});
            std::vector<uint64_t> selected;
            selected.reserve(max_degree_);
            // Experimental alpha=1 occlusion, following the native pruning strategy.
            // This is not an exported policy or an exact HGraph transplantation.
            for (const auto& candidate : ranked) {
                bool accepted = true;
                for (const uint64_t neighbor : selected) {
                    if (distance(neighbor, candidate.slot) < candidate.distance) {
                        accepted = false;
                        break;
                    }
                }
                if (accepted) {
                    selected.push_back(candidate.slot);
                    if (selected.size() == max_degree_) {
                        break;
                    }
                }
            }
            // Unlike native HGraph, Lite's degree-retention contract requires refilling
            // occluded candidates after the diversity pass, up to the existing cap.
            for (const auto& candidate : ranked) {
                if (selected.size() == max_degree_) {
                    break;
                }
                if (std::find(selected.begin(), selected.end(), candidate.slot) == selected.end()) {
                    selected.push_back(candidate.slot);
                }
            }
            replace_neighbors(source, selected);
        }
        std::sort(targets.begin(), targets.end());
        targets.erase(std::unique(targets.begin(), targets.end()), targets.end());
        for (const uint64_t target : targets) {
            if (target < Size()) {
                ensure_incoming(target);
            }
        }
    }
'''
candidate=root/'graph_backend.cpp'
candidate.write_text(original[:begin]+replacement+original[end:])
subprocess.run(['clang-format-15','--style=file:'+str(repo/'.clang-format'),'-i',str(candidate)],check=True)
patch=''.join(difflib.unified_diff(original.splitlines(True),candidate.read_text().splitlines(True),fromfile='a/src/lite/graph_backend.cpp',tofile='b/src/lite/graph_backend.cpp'))
(root/'candidate.diff').write_text(patch)
(root/'baseline.cpp').write_text(original)
commands=[]
env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1'}
def run(tag,argv,extra=None):
    start=time.monotonic()
    with (root/(tag+'.log')).open('w') as stream:
        result=subprocess.run(argv,cwd=repo,env={**env,**(extra or {})},stdout=stream,stderr=subprocess.STDOUT)
    commands.append(dict(tag=tag,argv=list(map(str,argv)),exit=result.returncode,seconds=time.monotonic()-start))
    (root/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    print(tag,result.returncode,flush=True)
    return result.returncode
entries=json.loads((build/'compile_commands.json').read_text())
entry=next(e for e in entries if e['file'].endswith('/graph_backend.cpp'))
arguments=shlex.split(entry['command'])
arguments[arguments.index('-o')+1]=str(root/'candidate.o')
arguments[-1]=str(candidate)
assert run('candidate-compile',arguments)==0
assert run('candidate-tidy',['clang-tidy-15',str(candidate),'--config-file='+str(repo/'.clang-tidy'),
    '--header-filter=.*/pr2926-repair-pilot-r2-20261023/.*','--',*shlex.split(entry['command'])[1:shlex.split(entry['command']).index('-o')]])==0
link=subprocess.check_output(['ninja','-C',str(build),'-t','commands','vsag_lite'],text=True).splitlines()[-1]
assert link.startswith(': && ') and link.endswith(' && :')
linkargs=shlex.split(link[5:-5])
linkargs[linkargs.index('-o')+1]=str(root/'libvsag-lite.so')
for i,arg in enumerate(linkargs):
    if arg.endswith('graph_backend.cpp.o'):linkargs[i]=str(root/'candidate.o')
    elif arg.endswith('.o'):linkargs[i]=str(build/arg)
assert run('candidate-link',linkargs)==0
testenv={'LD_LIBRARY_PATH':str(root)}
assert run('candidate-ldd',['ldd',str(scope/'release-on/lite_graph_tests')],testenv)==0
assert str(root/'libvsag-lite.so') in (root/'candidate-ldd.log').read_text()
tests=run('candidate-ctest',['ctest','--test-dir',str(scope/'release-on'),'--output-on-failure'],testenv)
identity=dict(parent='f60c0fb5871bdacaa150fdf315eba19a2796ad64',baseline_library_sha256=baseline_sha,
    candidate_library_sha256=sha(root/'libvsag-lite.so'),candidate_source_sha256=sha(candidate),
    production_source_sha256=sha(repo/'src/lite/graph_backend.cpp'),only_production_overlay='repair function',
    native_reference=['src/algorithm/hgraph/hgraph_modify.cpp:140','src/impl/pruning_strategy.cpp:100'],
    degree_cap=16,construction_ef=128,query_ef=512,alpha=1.0,
    boundary='Experimental repair reselects current and deleted-neighbor candidates with alpha1 occlusion plus nearest remaining-candidate refill, keeping the existing cap. Not identical to native HGraph; not a production fix.')
(root/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
if tests:
    (root/'rejected.json').write_text(json.dumps(dict(reason='Existing release regressions fail; do not promote or claim performance',commands=commands),indent=2)+'\n')
    raise SystemExit(0)
probe_source=(formal/'slot-controls/slot-control.cpp').read_text()
anchor='    auto maintained = build(canonical_order);\n'
assert probe_source.count(anchor)==1
probe_source=probe_source.replace(anchor,anchor+'''    {
        std::ofstream initial(output / "initial.snapshot", std::ios::binary);
        require(static_cast<bool>(maintained->Save(initial)), "initial save failed");
        initial.close();
        require(static_cast<bool>(initial), "initial snapshot failed");
    }
''')
cpp=root/'probe.cpp';cpp.write_text(probe_source)
subprocess.run(['clang-format-15','--style=file:'+str(repo/'.clang-format'),'-i',str(cpp)],check=True)
assert run('probe-compile',['c++','-std=c++17','-O3','-DNDEBUG','-Wall','-Wextra','-Wpedantic',
    '-I'+str(repo/'include'),str(cpp),'-L'+str(build),'-Wl,-rpath,'+str(build),'-lvsag-lite','-o',str(root/'probe')])==0
dataset='/home/ubuntu/project/pr2926-three-dataset-resident-20261019/prepared/GIST/scale-10000'
for side in ['baseline','candidate']:
    assert run(side,['taskset','-c','0',str(root/'probe'),dataset,str(root/side),'reinsert','100','250'],
        {'LD_LIBRARY_PATH':str(build if side=='baseline' else root)})==0
baseline=root/'baseline';new=root/'candidate'
assert sha(baseline/'initial.snapshot')==sha(new/'initial.snapshot'), 'Initial graph not equal'
reference=json.loads((formal/'slot-controls/reinsert/audit.json').read_text())
assert sha(baseline/'maintained.snapshot')==reference['snapshots']['maintained.snapshot']['sha256']
def read(path):
    with path.open() as stream:return list(csv.DictReader(stream))
allrows={side:read(root/side/'neighbors.csv') for side in ['baseline','candidate']}
qualities={}
for side,rows in allrows.items():
    assert len(rows)==20000
    qualities[side]={}
    for ef in [512,10000]:
        selected=[r for r in rows if int(r['ef'])==ef]
        hits=0
        for q in range(1000):
            group=selected[q*10:(q+1)*10]
            ref=[r for r in allrows['baseline'] if int(r['ef'])==ef and int(r['query'])==q]
            assert [(r['query'],r['rank'],r['truth_id']) for r in group]==[(r['query'],r['rank'],r['truth_id']) for r in ref]
            vals=[(float(r['maintained_distance']),int(r['maintained_id'])) for r in group]
            assert vals==sorted(vals) and len({i for _,i in vals})==10
            hits+=len({int(r['truth_id']) for r in group}&{i for _,i in vals})
        qualities[side][str(ef)]=hits/10000
assert qualities['baseline']=={'512':.9125,'10000':1.0}
assert qualities['candidate']['10000']==1.0
assert sha(build/'libvsag-lite.so')==baseline_sha
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
(root/'completed.json').write_text(json.dumps(dict(status='PILOT_ONLY',quality=qualities,initial_snapshot_equal=True,
    baseline_final_snapshot_equals_E14=True,commands=commands,
    limitation='One FP32 unchanged-value reinsert process per variant, no interleaved queries; not a paired CPU benchmark or cross-dataset optimization'),indent=2)+'\n')
print(json.dumps(qualities),flush=True)
