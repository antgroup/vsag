"""Reclaim only this new pilot's verified, replayable temporary snapshots after audit."""
from pathlib import Path
import hashlib,json,time,os
root=Path('/home/ubuntu/project/pr2926-repair-followup-20261023').resolve(strict=True)
assert root==Path('/home/ubuntu/project/pr2926-repair-followup-20261023')
assert root.is_dir() and not root.is_symlink()
os.sched_setaffinity(0,{1})
records=[];released=set()
receipt=root/'released-snapshot-receipts.json'
assert not receipt.exists()
while True:
    try:
        rows=json.loads((root/'rows.json').read_text())
    except (FileNotFoundError,json.JSONDecodeError):
        rows=[]
    for row in rows:
        assert row['initial_snapshot_equal'] and row['final_geometry_layout_equal']
        tag=f"{row['dataset']}-{row['storage']}-{row['workload']}"
        for side in ['baseline','candidate']:
            name=tag+'-'+side
            if name in released:continue
            folder=(root/name).resolve(strict=True)
            assert folder.parent==root and not (root/name).is_symlink()
            items=[]
            for filename in ['initial.snapshot','maintained.snapshot','canonical.snapshot','same_order.snapshot']:
                path=folder/filename
                assert not path.is_symlink() and path.resolve(strict=True).parent==folder
                data=path.read_bytes()
                items.append(dict(path=str(path.relative_to(root)),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
            maintained=next(i for i in items if i['path'].endswith('/maintained.snapshot'))
            assert maintained['sha256']==row[side+'_sha256']
            records.append(dict(cell=name,all_checks_finished=True,snapshots=items,
                recovery='Replay the frozen source, source-bound library/input identities and deterministic operations; all CSV and source files retained'))
            receipt.write_text(json.dumps(records,indent=2)+'\n')
            assert json.loads(receipt.read_text())==records
            for item in items:
                path=root/item['path']
                assert path.stat().st_size==item['bytes'] and hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256']
                path.unlink()
            released.add(name)
    if (root/'completed.json').exists() and len(released)==14:break
    time.sleep(2)
print('Verified temporary snapshots released: '+str(len(released)),flush=True)
