"""Frozen follow-up after the first positive FP32 reinsert pilot. No repository writes."""
from pathlib import Path
import csv,hashlib,json,os,shlex,subprocess,time,struct,math
repo=Path('/home/ubuntu/project/vsag-pr2926-report-20261019')
scope=Path('/home/ubuntu/project/pr2926-community-scope-20261022')
pilot=Path('/home/ubuntu/project/pr2926-repair-pilot-r2-20261023')
root=Path('/home/ubuntu/project/pr2926-repair-followup-20261023')
build=scope/'reproduction/source-bound-build'
root.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((pilot/'completed.json').read_text())['quality']['candidate']['512']==.9811
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
commands=[]
env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1'}
def run(tag,argv,extra=None):
    start=time.monotonic()
    with (root/(tag+'.log')).open('w') as log:
        result=subprocess.run(argv,cwd=repo,env={**env,**(extra or {})},stdout=log,stderr=subprocess.STDOUT)
    commands.append(dict(tag=tag,argv=list(map(str,argv)),exit=result.returncode,seconds=time.monotonic()-start))
    (root/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    print(tag,result.returncode,flush=True)
    assert result.returncode==0,tag
# Rebuild just the candidate TU under the existing sanitizer flags; all other objects are unchanged.
san=scope/'sanitizer'
entry=next(e for e in json.loads((san/'compile_commands.json').read_text()) if e['file'].endswith('/graph_backend.cpp'))
arguments=shlex.split(entry['command'])
arguments[arguments.index('-o')+1]=str(root/'san-candidate.o')
arguments[-1]=str(pilot/'graph_backend.cpp')
run('san-compile',arguments)
link=subprocess.check_output(['ninja','-C',str(san),'-t','commands','vsag_lite'],text=True).splitlines()[-1]
assert link.startswith(': && ') and link.endswith(' && :')
linkargs=shlex.split(link[5:-5]);linkargs[linkargs.index('-o')+1]=str(root/'libvsag-lite.so')
for i,arg in enumerate(linkargs):
    if arg.endswith('graph_backend.cpp.o'):linkargs[i]=str(root/'san-candidate.o')
    elif arg.endswith('.o'):linkargs[i]=str(san/arg)
run('san-link',linkargs)
sanenv={'LD_LIBRARY_PATH':str(root),'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'}
run('san-ldd',['ldd',str(san/'lite_graph_tests')],sanenv)
assert str(root/'libvsag-lite.so') in (root/'san-ldd.log').read_text()
run('san-ctest',['ctest','--test-dir',str(san),'--output-on-failure'],sanenv)
# Keep the probe's independent truth, snapshots and full-query evidence; expand the mutation split.
source=(pilot/'probe.cpp').read_text()
source=source.replace('require(argc == 6,','require(argc == 7,',1)
old='require(mode == "replace" or mode == "reinsert", "invalid mode");'
assert source.count(old)==1
source=source.replace(old,'''require(mode == "replace" or mode == "reinsert" or mode == "update", "invalid mode");
    const std::string storage(argv[6]);
    require(storage == "fp32" or storage == "fp16", "invalid storage");
    const auto format = storage == "fp32" ? vsag::lite::VectorStorage::FP32 : vsag::lite::VectorStorage::FP16;''')
source=source.replace('vsag::lite::VectorStorage::FP32, 16, 128','format, 16, 128',1)
source=source.replace('if (mode == "replace") {','if (mode != "reinsert") {',1)
start=source.index('    for (uint64_t round = 1; round <= rounds; ++round) {')
stop=source.index('    auto canonical = build(canonical_order);',start)
loop=source[start:stop]
anchor='            require(maintained->Remove('
offset=loop.index(anchor)
mutations=loop[offset:loop.index('            base[id] = replacement;',offset)]
loop=loop.replace(mutations,'''            if (mode == "update") {
                require(static_cast<bool>(maintained->Update(static_cast<int64_t>(id), replacement.data(), dim)), "update failed");
            } else {
'''+mutations+'''            }
''')
loop=loop.replace('            slots[id] = order.size();\n            order.push_back(id);','''            if (mode != "update") {
                slots[id] = order.size();
                order.push_back(id);
            }''')
source=source[:start]+'''    const auto mutation_start = std::chrono::steady_clock::now();
'''+loop+'''    const auto mutation_end = std::chrono::steady_clock::now();
    std::ofstream mutation_time(output / "mutation-time.csv");
    mutation_time << "calls,wall_ms\\n" << std::setprecision(17) << rounds * cycles * (mode == "update" ? 1 : 2) << ','
        << std::chrono::duration<double, std::milli>(mutation_end - mutation_start).count() << '\\n';
    mutation_time.close();
    require(static_cast<bool>(mutation_time), "mutation timing write failed");
'''+source[stop:]
cpp=root/'probe.cpp';cpp.write_text(source)
subprocess.run(['clang-format-15','--style=file:'+str(repo/'.clang-format'),'-i',str(cpp)],check=True)
run('probe-tidy',['clang-tidy-15',str(cpp),'--config-file='+str(repo/'.clang-tidy'),
    '--header-filter=.*/pr2926-repair-followup-20261023/.*','--','-std=c++17','-I'+str(repo/'include')])
run('probe-compile',['c++','-std=c++17','-O3','-DNDEBUG','-Wall','-Wextra','-Wpedantic','-I'+str(repo/'include'),
    str(cpp),'-L'+str(build),'-Wl,-rpath,'+str(build),'-lvsag-lite','-o',str(root/'probe')])
# Predeclare all cells and rotate variant order. One process/cell/variant; not a repeated timing claim.
plan=[('GIST','fp32','update'),('GIST','fp32','replace'),('GIST','fp16','update'),
      ('GIST','fp16','replace'),('GIST','fp16','reinsert'),('SIFT','fp32','reinsert'),('Cohere','fp32','reinsert')]
(root/'plan.json').write_text(json.dumps(dict(cells=plan,rounds=100,cycles=250,degree_cap=16,construction_ef=128,query_ef=512,
    boundary='Single-process paired pilot extension; no interleaved queries, only final quality. Loop wall includes vector recipe and bookkeeping; not API-only latency.'),indent=2)+'\n')
def read(path):
    with path.open() as stream:return list(csv.DictReader(stream))
def snapshot(path,storage):
    with path.open('rb') as stream:
        header=struct.unpack('<8s7Q',stream.read(64));count=header[3];dim=header[2]
        ids=stream.read(count*8);vectors=stream.read(count*dim*(2 if storage=='fp16' else 4))
    return dict(header=header,ids=ids,vectors=vectors,sha256=sha(path),bytes=path.stat().st_size)
summaries=[]
for number,(dataset,storage,mode) in enumerate(plan):
    tag=f'{dataset}-{storage}-{mode}'
    data=Path('/home/ubuntu/project/pr2926-three-dataset-resident-20261019/prepared')/dataset/'scale-10000'
    assert data.is_dir()
    for side in (['baseline','candidate'] if number%2==0 else ['candidate','baseline']):
        run(tag+'-'+side,['taskset','-c','0',str(root/'probe'),str(data),str(root/(tag+'-'+side)),mode,'100','250',storage],
            {'LD_LIBRARY_PATH':str(build if side=='baseline' else pilot)})
    dirs={side:root/(tag+'-'+side) for side in ['baseline','candidate']}
    assert sha(dirs['baseline']/'initial.snapshot')==sha(dirs['candidate']/'initial.snapshot')
    a,b=(snapshot(dirs[side]/'maintained.snapshot',storage) for side in ['baseline','candidate'])
    assert a['header'][:4]==b['header'][:4] and a['header'][5:]==b['header'][5:]
    assert a['ids']==b['ids'] and a['vectors']==b['vectors'], 'Stored geometry/layout differs'
    rows={side:read(folder/'neighbors.csv') for side,folder in dirs.items()}
    assert len(rows['baseline'])==len(rows['candidate'])==20000
    quality={}
    for side in dirs:
        quality[side]={}
        for ef in [512,10000]:
            selected=[r for r in rows[side] if int(r['ef'])==ef]
            reference=[r for r in rows['baseline'] if int(r['ef'])==ef]
            assert [(r['query'],r['rank'],r['truth_id']) for r in selected]==[(r['query'],r['rank'],r['truth_id']) for r in reference]
            hits={view:0 for view in ['maintained','canonical','same_order']}
            for q in range(1000):
                group=selected[q*10:(q+1)*10]
                truth={int(r['truth_id']) for r in group}
                for view in hits:
                    values=[(float(r[view+'_distance']),int(r[view+'_id'])) for r in group]
                    assert values==sorted(values) and len({i for _,i in values})==10
                    assert all(math.isfinite(d) and 0<=i<10000 for d,i in values)
                    hits[view]+=len(truth & {i for _,i in values})
            quality[side][str(ef)]={view:count/10000 for view,count in hits.items()}
            for view in ['canonical','same_order']:
                assert [(r[view+'_id'],r[view+'_distance']) for r in selected]==[(r[view+'_id'],r[view+'_distance']) for r in reference]
        assert quality[side]['10000']==quality['baseline']['10000']
    if dataset=='GIST':
        expected=json.loads((formal/mode/('GIST-'+storage+'-0')/'audit.json').read_text())['snapshots']['round-100']
        assert a['sha256']==expected['sha256']
    times={side:read(folder/'mutation-time.csv')[0] for side,folder in dirs.items()}
    summaries.append(dict(dataset=dataset,storage=storage,workload=mode,quality=quality,loop_time=times,
        initial_snapshot_equal=True,final_geometry_layout_equal=True,baseline_sha256=a['sha256'],candidate_sha256=b['sha256']))
    (root/'rows.json').write_text(json.dumps(summaries,indent=2)+'\n')
    print(tag,json.dumps(quality),flush=True)
assert sha(pilot/'graph_backend.cpp')==json.loads((pilot/'identity.json').read_text())['candidate_source_sha256']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
(root/'completed.json').write_text(json.dumps(dict(status='PILOT_EXTENSION_COMPLETE',cells=len(plan),rows=summaries,
    production_unchanged=True,sanitizer_5_tests_passed=True),indent=2)+'\n')
